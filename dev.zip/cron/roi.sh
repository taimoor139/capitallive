#!/bin/sh
cd  /home/u511512799/public_html/ && php artisan return_on_investment:earning >> /dev/null 2>&1