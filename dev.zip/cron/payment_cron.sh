#!/bin/sh
cd  /home/u511512799/public_html/ && php artisan schedule:run >> /dev/null 2>&1