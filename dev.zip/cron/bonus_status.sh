#!/bin/sh
cd  /home/u511512799/public_html/ && php artisan bonus_status:check >> /dev/null 2>&1