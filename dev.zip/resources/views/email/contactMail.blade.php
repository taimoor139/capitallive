<br><br>
Hi {{ $name }},<br>

User details: <br><br>



Name:  {{ $name }}<br>

 Email:  {{ $email }}<br>

 Subject:  {{ $subject }}<br>

{!! $data !!}<br><br>


