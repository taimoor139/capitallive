<?php

namespace App\Console\Commands;

use App\Models\Balance;
use App\Models\Bonus;
use App\Models\Deposit;
use App\Models\Point;
use App\Models\Referral;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class PaymentStatusCheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'payment_status:check';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'To check payment status from coin payment api';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        Deposit::query()->select('transactionId')->whereNotIn('status', [100, -1])->chunk(50, function ($depositData) {
            foreach ($depositData as $data) {
                $cpApi = new \CoinpaymentsAPI(env('CP_PRIVATE_KEY'), env('CP_PUBLIC_KEY'), 'json');
                $status = $cpApi->GetTxInfoSingle($data->transactionId);

                Deposit::query()->where('transactionId', $data->transactionId)->update([
                    'status' => $status['result']['status']
                ]);

                Transaction::query()->where('transaction_id', $data->transactionId)->update([
                    'status' => $status['result']['status']
                ]);

                if ($status['result']['status'] == 100) {

                    $directBonus = 0;
                    $networkBonus = 0;


                    $deposit = Deposit::query()->where('transactionId', $data->transactionId)->first();


                    if ($deposit && $deposit->referral) {
                        $userEarning = User::query()->where('id', $deposit->userId)->update(['earning_status', 1]);
                        if ($deposit->referral->position == 0 && $deposit->referral->pairStatus == 0) {
                            $rightUnpaired = Referral::query()->where(['position' => 1, 'pairStatus' => 0, 'referrer_name' => $deposit->referral->referrer_name])->whereHas('deposit', function ($referralDeposit) use($deposit) {
                                $referralDeposit->where('status', 100)->where('amount', ">=", $deposit->amount);
                            })->first();
                            if ($rightUnpaired) {
                                $balance = 0;

                                $updateLeftReferral = Referral::query()->where('id', $deposit->referral->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $rightUnpaired->user_id
                                ]);

                                $updateRightReferral = Referral::query()->where('id', $rightUnpaired->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $deposit->userId
                                ]);

                                $directBonus = ($deposit->amount * 4) / 100;
                                $networkBonus = ($deposit->amount * 3) / 100;


                                $parentId = User::query()->where('username', $deposit->referral->referrer_name)->first();

                                $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                                if ($previousBalance) {
                                    $balance = $previousBalance->balance + $directBonus + $networkBonus;
                                } else {
                                    $balance = $directBonus + $networkBonus;
                                }

                                $this->bonusPoints($parentId->id, $deposit->referral->position, $deposit->amount);
                                
                                $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                    'balance' => $balance
                                ]);

                                $child = 1;


                                $bonus = new  Bonus();
                                $bonus->type = 1;
                                $bonus->from = $child;
                                $bonus->amount = $networkBonus;
                                $bonus->percentage = '3';
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 0;
                                $bonus->save();

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = '4';
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 0;
                                $bonus->save();

                                if ($updateParentBalance) {
                                    $parentReferrer = Referral::query()->where('user_id', $parentId->id)->first();
                                    $points = Point::query()->where('user_id', $parentId->id)->first();

                                    if ($parentReferrer && $parentReferrer->pairStatus == 1 && $points->left_bp > 0 && $points->right_bp > 0 && $points->left_bp == $points->right_bp) {
                                        $this->referralbonus($parentReferrer->referrer_name, $networkBonus, $child);
                                    }
                                }

                            } else {

                                $parentId = User::query()->where('username', $deposit->referral->referrer_name)->first();

                                $directBonus = ($deposit->amount * 4) / 100;

                                $balance = 0;

                                $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                                if ($previousBalance) {
                                    $balance = $previousBalance->balance + $directBonus;
                                } else {
                                    $balance = $directBonus;
                                }

                                $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                    'balance' => $balance
                                ]);

                                $this->bonusPoints($parentId->id, $deposit->referral->position, $deposit->amount);

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = '4';
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 0;
                                $bonus->save();
                            }
                        }
                        if ($deposit->referral->position == 1 && $deposit->referral->pairStatus == 0) {
                            $leftUnpaired = Referral::query()->where(['position' => 0, 'pairStatus' => 0, 'referrer_name' => $deposit->referral->referrer_name])->whereHas('deposit', function ($referralDeposit) use ($deposit) {
                                $referralDeposit->where('status', 100)->where('amount', ">=", $deposit->amount);
                            })->first();
                            if ($leftUnpaired) {
                                $balance = 0;
                                $updateRightReferral = Referral::query()->where('id', $deposit->referral->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $leftUnpaired->user_id
                                ]);

                                $updateLeftReferral = Referral::query()->where('id', $leftUnpaired->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $deposit->userId
                                ]);

                                $directBonus = ($deposit->amount * 4) / 100;
                                $networkBonus = ($deposit->amount * 3) / 100;

                                $parentId = User::query()->where('username', $deposit->referral->referrer_name)->first();
                                $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                                if ($previousBalance) {
                                    $balance = $previousBalance->balance + $directBonus + $networkBonus;
                                } else {
                                    $balance = $directBonus + $networkBonus;
                                }

                                $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                    'balance' => $balance
                                ]);

                                $this->bonusPoints($parentId->id, $deposit->referral->position, $deposit->amount);

                                if ($updateParentBalance) {

                                    $child = 1;

                                    $bonus = new  Bonus();
                                    $bonus->type = 2;
                                    $bonus->amount = $directBonus;
                                    $bonus->percentage = "4";
                                    $bonus->user_id = $parentId->id;
                                    $bonus->status = 0;
                                    $bonus->save();

                                    $bonus = new  Bonus();
                                    $bonus->type = 1;
                                    $bonus->from = $child;
                                    $bonus->amount = $networkBonus;
                                    $bonus->percentage = "3";
                                    $bonus->user_id = $parentId->id;
                                    $bonus->status = 0;
                                    $bonus->save();

                                    $parentReferrer = Referral::query()->where('user_id', $parentId->id)->first();
                                    $points = Point::query()->where('user_id', $parentId->id)->first();

                                    if ($parentReferrer && $parentReferrer->pairStatus == 1 && $points->left_bp > 0 && $points->right_bp > 0 && $points->left_bp == $points->right_bp) {
                                        $this->referralbonus($parentReferrer->referrer_name, $networkBonus, $child);
                                    }

                                }

                            } else {

                                $directBonus = ($deposit->amount * 4) / 100;

                                $parentId = User::query()->where('username', $deposit->referral->referrer_name)->first();

                                $balance = 0;
                                $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                                if ($previousBalance) {
                                    $balance = $previousBalance->balance + $directBonus;
                                } else {
                                    $balance = $directBonus ;
                                }

                                $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                    'balance' => $balance
                                ]);

                                $this->bonusPoints($parentId->id, $deposit->referral->position, $deposit->amount);

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = '4';
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 0;
                                $bonus->save();

                            }
                        }
                        if ($deposit->referral && $deposit->referral->pairStatus == 1) {

                            $parentId = User::query()->where('username', $deposit->referral->referrer_name)->first();
                            if ($parentId) {

                                $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                                if ($previousBalance) {
                                    $balance = $previousBalance->balance + $directBonus + $networkBonus;
                                } else {
                                    $balance = $directBonus + $networkBonus;
                                }

                                $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                    'balance' => $balance
                                ]);

                                $this->bonusPoints($parentId->id, $deposit->referral->position, $deposit->amount);

                                if ($updateParentBalance) {

                                    $bonus = new  Bonus();
                                    $bonus->type = 2;
                                    $bonus->amount = $directBonus;
                                    $bonus->percentage = "4";
                                    $bonus->user_id = $parentId->id;
                                    $bonus->status = 100;
                                    $bonus->save();

                                }
                            }

                        }

                    }
                }
            }
        });
    }

    public function referralbonus($parentUsername, $network, $child)
    {
        $child = $child + 1;
        $parent = User::query()->where('username', $parentUsername)->first();
        if ($parent) {
            $parentId = $parent->id;
            $balance = 0;
            $previousBalance = Balance::query()->where('user_id', $parentId)->first();
            if ($previousBalance) {
                $balance = $previousBalance->balance + $network;
            } else {
                $balance = $network;
            }

            $previousPoints = Point::query()->where('user_id', $parentId)->first();
            if ($previousPoints) {
                $leftBP = $previousPoints->left_bp +  $network;
                $rightBp = $previousPoints->right_bp +  $network;

                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'left_bp' => $leftBP,
                    'right_bp' => $rightBp
                ]);

            } else {
                $leftBP = $network;
                $rightBp = $network;

                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'left_bp' => $leftBP,
                    'right_bp' => $rightBp
                ]);
            }


            if ($balance) {
                $updateParentBalance = Balance::query()->where('user_id', $parentId)->update([
                    'balance' => $balance
                ]);
                if ($updateParentBalance) {
                    $parentReferrer = Referral::query()->where('user_id', $parentId)->first();
                    $bonus = new  Bonus();
                    $bonus->type = 1;
                    $bonus->amount = $network;
                    $bonus->percentage = '3';
                    $bonus->user_id = $parentId;
                    $bonus->status = 0;
                    $bonus->save();

                    if ($parentReferrer && $parentReferrer->pairStatus == 1) {

                        $this->referralbonus($parentReferrer->referrer_name, $network, $child);
                    }
                }
            }
        }
    }
    public function bonusPoints($parentId, $position, $bonus){
        $previousPoints = Point::query()->where('user_id', $parentId)->first();
        if($position == 0){
            if ($previousPoints) {
                $leftBP = $previousPoints->left_bp + $bonus;
                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'left_bp' => $leftBP,
                ]);

            }
        } else if($position == 1){
            if ($previousPoints) {
                $rightBP = $previousPoints->right_bp + $bonus;
                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'right_bp' => $rightBP,
                ]);

            }
        }

        $referrerCheck = Referral::query()->where('user_id', $parentId)->first();

        if($referrerCheck){
            $userId = User::query()->where('username', $referrerCheck->referrer_name)->first();

            if($userId){
                $this->bonusPoints($userId->id, $referrerCheck->position, $bonus);
            }
        }
    }


}
