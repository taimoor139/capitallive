<?php

namespace App\Http\Controllers;

use App\Models\Balance;
use App\Models\Bonus;
use App\Models\Deposit;
use App\Models\DepositLimit;
use App\Models\Point;
use App\Models\Referral;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class DepositController extends Controller
{
    public function index()
    {
        $fx1Limit = 0;
        $fx2Limit = 0;
        $fx3Limit = 0;

        $depositTypes = DepositLimit::all();

        $deposits = Deposit::query()->where('userId', Auth::user()->id)->get();
        $fx1 = DepositLimit::query()->where('account_type', 'CF Standard Account')->first();
        if ($fx1) {
            $fx1Limit = $fx1->limit;
        }
        $fx2 = DepositLimit::query()->where('account_type', 'CF Pro Account')->first();
        if ($fx2) {
            $fx2Limit = $fx2->limit;
        }
        $fx3 = DepositLimit::query()->where('account_type', 'CF Brokerage Account')->first();
        if ($fx3) {
            $fx3Limit = $fx3->limit;
        }
        return view('user.deposit.deposit', compact('deposits', 'fx1Limit', 'fx2Limit', 'fx3Limit',
            'depositTypes'));
    }

    public function depositStore(Request $request)
    {
        try {
            $request->validate([
                'accountType' => 'required',
                'currency' => 'required',
                'amount' => 'required'
            ]);


            $cpApi = new \CoinpaymentsAPI(env('CP_PRIVATE_KEY'), env('CP_PUBLIC_KEY'), 'json');
            $depositTransaction = $cpApi->CreateSimpleTransactionWithConversion($request->amount, 'USD', $request->currency, Auth::user()->email);

            if ($depositTransaction && !is_null($depositTransaction['result'])) {
                $status = $cpApi->GetTxInfoSingle($depositTransaction['result']['txn_id']);
                $deposit = new Deposit();
                $deposit->accountType = $request->accountType;
                $deposit->currency = $request->currency;
                $deposit->amount = $request->amount;
                $deposit->userId = Auth::user()->id;
                $deposit->transactionId = $depositTransaction['result']['txn_id'];
                $deposit->status = $status['result']['status'];
                if ($deposit->save()) {
                    $statusUrl = $depositTransaction['result']['status_url'];

                    $transaction = new Transaction();
                    $transaction->type = 'deposit';
                    $transaction->user_id = Auth::user()->id;
                    $transaction->amount = $request->amount;
                    $transaction->transaction_id = $depositTransaction['result']['txn_id'];
                    $transaction->status = $status['result']['status'];
                    $transaction->save();
                }


            }

            return $statusUrl;
        } catch (\Exception $e) {
            return 0;
        }

    }

    public function deposits()
    {
        $pageTitle = 'All Deposits';
        $deposits = Deposit::query()->with('user')->get();
        $successfulDeposits = Deposit::query()->where('status', 100)->sum('amount');
        $pendingDeposits = Deposit::query()->where('status', 0)->sum('amount');
        $rejectedDeposits = Deposit::query()->where('status', -1)->sum('amount');
        return view('admin.deposits.index', compact('deposits', 'successfulDeposits', 'pendingDeposits', 'rejectedDeposits', 'pageTitle'));
    }

    public function pendingDeposits()
    {
        $pageTitle = 'Pending Deposits';
        $deposits = Deposit::query()->where('status', 0)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }

    public function approvedDeposits()
    {
        $pageTitle = 'Approved Deposits';
        $deposits = Deposit::query()->where('status', 1)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }

    public function successfulDeposits()
    {
        $pageTitle = 'Successful Deposits';
        $deposits = Deposit::query()->where('status', 100)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }

    public function rejectedDeposits()
    {
        $pageTitle = 'Rejected Deposits';
        $deposits = Deposit::query()->where('status', -1)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }

    public function depositLimit()
    {
        $limits = DepositLimit::all();
        return view('admin.deposits.limit', compact('limits'));
    }

    public function addLimit(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'account_type' => 'required',
            'limit' => 'required'
        ]);

        if ($validate) {
            $limit = new DepositLimit();
            $limit->account_type = $request->account_type;
            $limit->limit = $request->limit;
            if ($limit->save()) {
                return redirect()->back()->with('success', 'Deposit limit added Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }

    public function updateLimit(Request $request)
    {
        $validate = Validator::make($request->all(), [
            'account_type' => 'required',
            'limit' => 'required'
        ]);

        if ($validate) {
            $update = DepositLimit::query()->where('id', $request->limit_id)->update([
                'account_type' => $request->account_type,
                'limit' => $request->limit,
            ]);

            if ($update) {
                return redirect()->back()->with('success', 'Deposit limit update Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }

    public function deleteLimit($id)
    {
        $withdraw = DepositLimit::query()->where('id', $id);
        if ($withdraw) {
            $delete = $withdraw->delete();
            if ($delete) {
                return redirect()->back()->with('success', 'Deposit limit Deleted Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }

    public function manualDeposit()
    {
        $fx1Limit = 0;
        $fx2Limit = 0;
        $fx3Limit = 0;
        $users = User::query()->where('role_id', 2)->get();
        $fx1 = DepositLimit::query()->where('account_type', 'CF Standard Account 50$')->first();
        if ($fx1) {
            $fx1Limit = $fx1->limit;
        }
        $fx2 = DepositLimit::query()->where('account_type', 'CF Pro Account 500$')->first();
        if ($fx2) {
            $fx2Limit = $fx2->limit;
        }
        $fx3 = DepositLimit::query()->where('account_type', 'CF Brokerage Account 1000$')->first();
        if ($fx3) {
            $fx3Limit = $fx3->limit;
        }
        return view('admin.deposits.manual', compact('users', 'fx1Limit', 'fx2Limit', 'fx3Limit'));
    }

    public function addManualDeposit(Request $request)
    {
//        try{
        $request->validate([
            'accountType' => 'required',
            'currency' => 'required',
            'amount' => 'required'
        ]);

        $user = User::query()->where('id', $request->user)->first();

        if ($user) {
            $deposit = new Deposit();
            $deposit->accountType = $request->accountType;
            $deposit->currency = $request->currency;
            $deposit->amount = $request->amount;
            $deposit->userId = $request->user;
            $deposit->transactionId = "manual";
            $deposit->status = 100;
            if ($deposit->save()) {
                $transaction = new Transaction();
                $transaction->type = 'deposit';
                $transaction->user_id = $request->user;
                $transaction->amount = $request->amount;
                $transaction->transaction_id = "manual";
                $transaction->status = 100;
                $transaction->save();


                $balance = 0;
                $directBonus = (4 * $request->amount) / 100;

                $previousBalance = Balance::query()->where('user_id', $request->user)->first();
//                if ($previousBalance) {
//                    $balance = $previousBalance->balance + $request->amount;
//                } else {
//                    $balance = $request->amount;
//                }

//                $updateBalance = Balance::query()->where('user_id', $request->user)->update([
//                    'balance' => $balance
//                ]);

                if ($user->referral && $user->referral->position == 0 && $user->referral->pairStatus == 0) {
                    $rightUnpaired = Referral::query()->where(['position' => 1, 'pairStatus' => 0, 'referrer_name' => $deposit->referral->referrer_name])->whereHas('deposit', function ($referralDeposit) use ($request) {
                        $referralDeposit->where('status', 100);
                    })->first();
                    if ($rightUnpaired) {
                        $parentId = User::query()->where('username', $user->referral->referrer_name)->first();
                        if ($parentId) {

                            if ($rightUnpaired->user->points->right_rp > $request->amount) {
                                $networkBonus = (3 * $request->amount) / 100;
                                $remainingPoints = (($rightUnpaired->user->points->right_rp - $request->amount) > 0 ? $rightUnpaired->user->points->right_rp - $request->amount : 0);

                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 1);
                            } else if ($rightUnpaired->user->points->right_rp < $request->amount && $rightUnpaired->user->points->right_rp > 0) {
                                $networkBonus = (3 * $rightUnpaired->user->points->right_rp) / 100;
                                $remainingPoints = (($request->amount - $rightUnpaired->user->points->right_rp) > 0 ? $request->amount - $rightUnpaired->user->points->right_rp : 0);
                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 0);
                            } else {
                                $networkBonus = (3 * $request->amount) / 100;
                                $remainingPoints = (($rightUnpaired->user->points->right_rp - $request->amount) > 0 ? $rightUnpaired->user->points->right_rp - $request->amount : 0);

                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 1);
                            }

                            $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                            if ($previousBalance) {
                                $balance = $previousBalance->balance + $directBonus + $networkBonus;
                            } else {
                                $balance = $directBonus + $networkBonus;
                            }

                            $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                'balance' => $balance
                            ]);


                            if ($updateParentBalance) {

                                $child = 1;

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = "4";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $bonus = new  Bonus();
                                $bonus->type = 1;
                                $bonus->from = $child;
                                $bonus->amount = $networkBonus;
                                $bonus->percentage = "3";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $parentReferrer = Referral::query()->where('user_id', $parentId->id)->first();
                                $points = Point::query()->where('user_id', $parentId->id)->first();

                                $updateLeftReferral = Referral::query()->where('id', $user->referral->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $rightUnpaired->user_id
                                ]);

                                $updateRightReferral = Referral::query()->where('id', $rightUnpaired->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $user->id
                                ]);
                                Log::info("in parent: ", ['its working']);
                                if ($parentReferrer && $parentReferrer->pairStatus == 1) {
                                    Log::info("in parent: ", ['its working']);
                                    $this->referralbonus($parentReferrer->referrer_name, $networkBonus, $child);
                                }


                            }
                        }
                    } else {
                        $parentId = User::query()->where('username', $user->referral->referrer_name)->first();
                        if ($parentId) {

                            $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                            if ($previousBalance) {
                                $balance = $previousBalance->balance + $directBonus;
                            } else {
                                $balance = $directBonus;
                            }

                            $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                'balance' => $balance
                            ]);

                            $remainingPoints = $parentId->points->right_rp;
                            if ($remainingPoints) {
                                $remainingPoints = $parentId->points->right_rp + $request->amount;
                            }

                            $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, $user->referral->position);

                            if ($updateParentBalance) {

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = "4";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $previousPoints = Point::query()->where('user_id', $parentId)->first();
                                if ($user->referral->position == 0) {
                                    if ($previousPoints) {
                                        $leftBP = $previousPoints->left_bp + $request->amount;
                                        $updatePoints = Point::query()->where('user_id', $parentId)->update([
                                            'left_bp' => $leftBP,
                                        ]);

                                    }
                                } else if ($user->referral->position == 1) {
                                    if ($previousPoints) {
                                        $rightBP = $previousPoints->right_bp + $request->amount;
                                        $updatePoints = Point::query()->where('user_id', $parentId)->update([
                                            'right_bp' => $rightBP,
                                        ]);

                                    }
                                }


                            }
                        }
                    }

                    Session::flash('success', 'Manual Deposit added successfully');
                    return 1;

                }
                if ($user->referral && $user->referral->position == 1 && $user->referral->pairStatus == 0) {
                    $leftUnpaired = Referral::query()->where(['position' => 0, 'pairStatus' => 0, 'referrer_name' => $user->referral->referrer_name])->whereHas('deposit', function ($referralDeposit) use ($request) {
                        $referralDeposit->where('status', 100);
                    })->first();
                    if ($leftUnpaired) {
                        $parentId = User::query()->where('username', $user->referral->referrer_name)->first();
                        if ($parentId) {

                            if ($leftUnpaired->user->points->left_rp > $request->amount) {
                                $networkBonus = (3 * $request->amount) / 100;
                                $remainingPoints = (($leftUnpaired->user->points->left_rp - $request->amount) > 0 ? $leftUnpaired->user->points->left_rp - $request->amount : 0);

                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 0);
                            } else if($leftUnpaired->user->points->left_rp < $request->amount && $leftUnpaired->user->points->left_rp > 0){
                                $networkBonus = (3 * $leftUnpaired->user->points->left_rp) / 100;
                                $remainingPoints = (($request->amount - $leftUnpaired->user->points->left_rp) > 0 ? $request->amount - $leftUnpaired->user->points->left_rp : 0);
                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 1);
                            } else {
                                $networkBonus = (3 * $request->amount) / 100;
                                $remainingPoints = (($leftUnpaired->user->points->left_rp - $request->amount) > 0 ? $leftUnpaired->user->points->left_rp - $request->amount : 0);

                                $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, 0);

                            }

                            $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                            if ($previousBalance) {
                                $balance = $previousBalance->balance + $directBonus + $networkBonus;
                            } else {
                                $balance = $directBonus + $networkBonus;
                            }

                            $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                'balance' => $balance
                            ]);


                            if ($updateParentBalance) {

                                $child = 1;

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = "4";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $bonus = new  Bonus();
                                $bonus->type = 1;
                                $bonus->from = $child;
                                $bonus->amount = $networkBonus;
                                $bonus->percentage = "3";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $parentReferrer = Referral::query()->where('user_id', $parentId->id)->first();
                                $points = Point::query()->where('user_id', $parentId->id)->first();

                                $updateLeftReferral = Referral::query()->where('id', $user->referral->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $leftUnpaired->user_id
                                ]);

                                $updateRightReferral = Referral::query()->where('id', $leftUnpaired->id)->update([
                                    'pairStatus' => 1,
                                    'pair_with' => $user->id
                                ]);

                                if ($parentReferrer && $parentReferrer->pairStatus == 1) {
                                    $this->referralbonus($parentReferrer->referrer_name, $networkBonus, $child);
                                }

                            }
                        }
                    } else {
                        $parentId = User::query()->where('username', $user->referral->referrer_name)->first();
                        if ($parentId) {

                            $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
                            if ($previousBalance) {
                                $balance = $previousBalance->balance + $directBonus;
                            } else {
                                $balance = $directBonus;
                            }

                            $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
                                'balance' => $balance
                            ]);

                            $remainingPoints = $parentId->points->right_rp;
                            if ($remainingPoints) {
                                $remainingPoints = $parentId->points->right_rp + $request->amount;
                            }

                            $this->bonusPoints($parentId->id, $user->referral->position, $request->amount, $remainingPoints, $user->referral->position);

                            if ($updateParentBalance) {

                                $bonus = new  Bonus();
                                $bonus->type = 2;
                                $bonus->amount = $directBonus;
                                $bonus->percentage = "4";
                                $bonus->user_id = $parentId->id;
                                $bonus->status = 100;
                                $bonus->save();

                                $previousPoints = Point::query()->where('user_id', $parentId)->first();
                                if ($user->referral->position == 0) {
                                    if ($previousPoints) {
                                        $leftBP = $previousPoints->left_bp + $request->amount;
                                        $updatePoints = Point::query()->where('user_id', $parentId)->update([
                                            'left_bp' => $leftBP,
                                        ]);

                                    }
                                } else if ($user->referral->position == 1) {
                                    if ($previousPoints) {
                                        $rightBP = $previousPoints->right_bp + $request->amount;
                                        $updatePoints = Point::query()->where('user_id', $parentId)->update([
                                            'right_bp' => $rightBP,
                                        ]);

                                    }
                                }


                            }
                        }
                    }

                    Session::flash('success', 'Manual Deposit added successfully');
                    return 1;

                }
//                if ($user->referral && $user->referral->pairStatus == 1) {
//
//                    $parentId = User::query()->where('username', $user->referral->referrer_name)->first();
//                    if ($parentId) {
//
//                        $previousBalance = Balance::query()->where('user_id', $parentId->id)->first();
//                        if ($previousBalance) {
//                            $balance = $previousBalance->balance + $directBonus + $networkBonus;
//                        } else {
//                            $balance = $directBonus + $networkBonus;
//                        }
//
//                        $updateParentBalance = Balance::query()->where('user_id', $parentId->id)->update([
//                            'balance' => $balance
//                        ]);
//
//                        $this->bonusPoints($parentId->id, $user->referral->position, $request->amount);
//
//                        if ($updateParentBalance) {
//
//                            $child = 1;
//
//                            $bonus = new  Bonus();
//                            $bonus->type = 2;
//                            $bonus->amount = $directBonus;
//                            $bonus->percentage = "4";
//                            $bonus->user_id = $parentId->id;
//                            $bonus->status = 100;
//                            $bonus->save();
//
//
//                        }
//                    }
//                    Session::flash('success', 'Manual Deposit added successfully');
//                    return 1;
//
//                }
                else {
                    Session::flash('danger', 'Something went wrong');
                    return 0;
                }

            }

//        } catch (\Exception $e){
//            return 0;
//        }
        }
    }

    public function referralbonus($parentUsername, $network, $child)
    {
        $child = $child + 1;
        $parent = User::query()->where('username', $parentUsername)->first();
        if ($parent) {
            $parentId = $parent->id;
            $balance = 0;
            $previousBalance = Balance::query()->where('user_id', $parentId)->first();
            if ($previousBalance) {
                $balance = $previousBalance->balance + $network;
            } else {
                $balance = $network;
            }

//            $previousPoints = Point::query()->where('user_id', $parentId)->first();
//            if ($previousPoints) {
//                $leftBP = $previousPoints->left_bp + $network;
//                $rightBp = $previousPoints->right_bp + $network;
//
//                $updatePoints = Point::query()->where('user_id', $parentId)->update([
//                    'left_bp' => $leftBP,
//                    'right_bp' => $rightBp
//                ]);
//
//            } else {
//                $leftBP = $network;
//                $rightBp = $network;
//
//                $updatePoints = Point::query()->where('user_id', $parentId)->update([
//                    'left_bp' => $leftBP,
//                    'right_bp' => $rightBp
//                ]);
//            }
            Log::info("in grand parent: ", ['its working']);
            if ($balance) {
                $updateParentBalance = Balance::query()->where('user_id', $parentId)->update([
                    'balance' => $balance
                ]);
                if ($updateParentBalance) {
                    $parentReferrer = Referral::query()->where('user_id', $parentId)->first();
                    $bonus = new  Bonus();
                    $bonus->type = 1;
                    $bonus->amount = $network;
                    $bonus->percentage = '3';
                    $bonus->user_id = $parentId;
                    $bonus->status = 0;
                    $bonus->save();

                    if ($parentReferrer && $parentReferrer->pairStatus == 1) {
                        Log::info("in grand grand parent: ", ['its working']);
                        $this->referralbonus($parentReferrer->referrer_name, $network, $child);
                    }
                }
            }
        }
    }

    public function bonusPoints($parentId, $position, $bonus, $remainingPoints, $pointPosition)
    {
        $previousPoints = Point::query()->where('user_id', $parentId)->first();
        if ($position == 0) {
            if ($previousPoints) {
                $leftBP = $previousPoints->left_bp + $bonus;
                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'left_bp' => $leftBP,
                ]);

            }
        } else if ($position == 1) {
            if ($previousPoints) {
                $rightBP = $previousPoints->right_bp + $bonus;
                $updatePoints = Point::query()->where('user_id', $parentId)->update([
                    'right_bp' => $rightBP,
                ]);

            }
        }

        if ($pointPosition == 0) {
            $updatePoints = Point::query()->where('user_id', $parentId)->update([
                'left_rp' => $remainingPoints,
            ]);
        } else if ($pointPosition == 1) {
            $updatePoints = Point::query()->where('user_id', $parentId)->update([
                'right_rp' => $remainingPoints,
            ]);
        }

        $referrerCheck = Referral::query()->where('user_id', $parentId)->first();

        if ($referrerCheck) {
            $userId = User::query()->where('username', $referrerCheck->referrer_name)->first();

            if ($userId) {
                if ($userId->points && $userId->points->right_rp) {
                    $remainingPoint = $userId->points->right_rp + $remainingPoints;
                } else {
                    $remainingPoint = $remainingPoints;
                }
                $this->bonusPoints($userId->id, $referrerCheck->position, $bonus, $remainingPoint, $referrerCheck->position);
            }
        }
    }
}
