<?php

return [
    /*
 * One Time Password View.
 */
    'view' => 'auth.2faVerify',
];
