<?php

namespace App\Console\Commands;

use App\Models\Balance;
use App\Models\Bonus;
use App\Models\Deposit;
use App\Models\Earning;
use App\Models\User;
use Illuminate\Console\Command;

class ReturnOnInvestment extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'return_on_investment:earning';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Return on Investment';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        if (date('l') != 'Saturday' && date('l') != 'Sunday') {
            $day = date('d');
            $dateCheck = $day % 2;
            Deposit::query()->where('status', 100)->chunk(50, function ($deposits) use ($dateCheck) {
                foreach ($deposits as $deposit) {
                    if($deposit->user->trade_activation == 1 && $deposit->user->earning_status == 1){

                        $balance = 0;
                        if($dateCheck == 0){
                            $roi = $deposit->returnOnInvestment->roi - 0.05;
                        } else {
                            $roi = $deposit->returnOnInvestment->roi ;
                        }

                        $earning = round(($roi / $deposit->amount) * 100, 4);
                        $roi_earning = new Earning();
                        $roi_earning->user_id = $deposit->userId;
                        $roi_earning->earning = $earning;
                        $roi_earning->percentage = $roi;
                        $roi_earning->status = 0;
                        if($roi_earning->save()){
                            $previousBalance = Balance::query()->where('user_id', $deposit->userId)->first();
                            if ($previousBalance) {
                                $balance = $previousBalance->balance + $earning;
                            } else {
                                $balance = $earning;
                            }

                            Balance::query()->where('user_id', $deposit->userId)->update([
                                'balance' => $balance
                            ]);
                        }
                    }
                }
            });
        }
    }
}
