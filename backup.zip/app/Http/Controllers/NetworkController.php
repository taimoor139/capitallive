<?php

namespace App\Http\Controllers;

use App\Models\Point;
use App\Models\Referral;
use Illuminate\Http\Request;
use Auth;

class NetworkController extends Controller
{
    public function index(){
        $totalLeftMembers = Referral::query()->where(['referrer_name' => Auth::user()->username, 'position' => 0])->whereNotNull(['user_id'])->count();
        $totalRightMembers = Referral::query()->where(['referrer_name' => Auth::user()->username, 'position' => 1])->whereNotNull(['user_id'])->count();
        $leftMembers = Referral::query()->with('user')->where(['referrer_name' => Auth::user()->username, 'position' => 0])->get();
        $rightMembers = Referral::query()->with('user')->where(['referrer_name' => Auth::user()->username, 'position' => 1])->get();
        $points = Point::query()->where('user_id', Auth::user()->id)->first();

        return view('user.network.genealogy', compact('totalLeftMembers', 'totalRightMembers', 'leftMembers', 'rightMembers', 'points'));
    }
}
