<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\DepositLimit;
use App\Models\Transaction;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class DepositController extends Controller
{
    public function index()
    {
        $fx1Limit = 0;
        $fx2Limit = 0;
        $fx3Limit = 0;

        $depositTypes = DepositLimit::all();

        $deposits = Deposit::query()->where('userId', Auth::user()->id)->get();
        $fx1 = DepositLimit::query()->where('account_type', 'CF Standard Account 50$')->first();
        if($fx1){
            $fx1Limit = $fx1->limit;
        }
        $fx2 = DepositLimit::query()->where('account_type', 'CF Pro Account 500$')->first();
        if($fx2){
            $fx2Limit = $fx2->limit;
        }
        $fx3 = DepositLimit::query()->where('account_type', 'CF Brokerage Account 1000$')->first();
        if($fx3){
            $fx3Limit = $fx3->limit;
        }
        return view('user.deposit.deposit', compact('deposits', 'fx1Limit', 'fx2Limit', 'fx3Limit',
            'depositTypes'));
    }
    public function depositStore(Request $request)
    {
        try{
            $request->validate([
                'accountType' => 'required',
                'currency' => 'required',
                'amount' => 'required'
            ]);



            $cpApi = new \CoinpaymentsAPI(env('CP_PRIVATE_KEY'), env('CP_PUBLIC_KEY'), 'json');
            $depositTransaction = $cpApi->CreateSimpleTransactionWithConversion($request->amount, 'USD', $request->currency, Auth::user()->email);

            if($depositTransaction && !is_null($depositTransaction['result'])){
                $status = $cpApi->GetTxInfoSingle($depositTransaction['result']['txn_id']);
                $deposit = new Deposit();
                $deposit->accountType = $request->accountType;
                $deposit->currency = $request->currency;
                $deposit->amount = $request->amount;
                $deposit->userId = Auth::user()->id;
                $deposit->transactionId = $depositTransaction['result']['txn_id'];
                $deposit->status = $status['result']['status'];
                if($deposit->save()){
                    $statusUrl = $depositTransaction['result']['status_url'];

                    $transaction = new Transaction();
                    $transaction->type = 'deposit';
                    $transaction->user_id = Auth::user()->id;
                    $transaction->amount = $request->amount;
                    $transaction->transaction_id = $depositTransaction['result']['txn_id'];
                    $transaction->status = $status['result']['status'];
                    $transaction->save();
                }


            }

            return $statusUrl;
        } catch (\Exception $e){
            return 0;
        }

    }
    public function deposits(){
        $pageTitle = 'All Deposits';
        $deposits = Deposit::query()->with('user')->get();
        $successfulDeposits = Deposit::query()->where('status', 100)->sum('amount');
        $pendingDeposits = Deposit::query()->where('status', 0)->sum('amount');
        $rejectedDeposits = Deposit::query()->where('status', -1)->sum('amount');
        return view('admin.deposits.index', compact('deposits', 'successfulDeposits', 'pendingDeposits', 'rejectedDeposits', 'pageTitle'));
    }
    public function pendingDeposits(){
        $pageTitle = 'Pending Deposits';
        $deposits = Deposit::query()->where('status', 0)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }
    public function approvedDeposits(){
        $pageTitle = 'Approved Deposits';
        $deposits = Deposit::query()->where('status', 1)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }
    public function successfulDeposits(){
        $pageTitle = 'Successful Deposits';
        $deposits = Deposit::query()->where('status', 100)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }
    public function rejectedDeposits(){
        $pageTitle = 'Rejected Deposits';
        $deposits = Deposit::query()->where('status', -1)->get();
        return view('admin.deposits.index', compact('deposits', 'pageTitle'));
    }
    public function depositLimit(){
        $limits = DepositLimit::all();
        return view('admin.deposits.limit', compact('limits'));
    }
    public function addLimit(Request $request){
        $validate = Validator::make($request->all(), [
            'account_type' => 'required',
            'limit' => 'required'
        ]);

        if($validate){
            $limit = new DepositLimit();
            $limit->account_type = $request->account_type;
            $limit->limit = $request->limit;
            if($limit->save()){
                return redirect()->back()->with('success', 'Deposit limit added Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }
    public function updateLimit(Request $request){
        $validate = Validator::make($request->all(), [
            'account_type' => 'required',
            'limit' => 'required'
        ]);

        if($validate){
            $update = DepositLimit::query()->where('id', $request->limit_id)->update([
                'account_type' => $request->account_type,
                'limit' => $request->limit,
            ]);

            if($update){
                return redirect()->back()->with('success', 'Deposit limit update Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }
    public function deleteLimit($id){
        $withdraw = DepositLimit::query()->where('id', $id);
        if($withdraw){
            $delete = $withdraw->delete();
            if($delete){
                return redirect()->back()->with('success', 'Deposit limit Deleted Successfully');
            } else {
                return redirect()->back()->with('error', 'Something went wrong');
            }
        }
    }
    public function manualDeposit(){
        $fx1Limit = 0;
        $fx2Limit = 0;
        $fx3Limit = 0;
        $users = User::query()->where('role_id', 2)->get();
        $fx1 = DepositLimit::query()->where('account_type', 'CF Standard Account 50$')->first();
        if($fx1){
            $fx1Limit = $fx1->limit;
        }
        $fx2 = DepositLimit::query()->where('account_type', 'CF Pro Account 500$')->first();
        if($fx2){
            $fx2Limit = $fx2->limit;
        }
        $fx3 = DepositLimit::query()->where('account_type', 'CF Brokerage Account 1000$')->first();
        if($fx3){
            $fx3Limit = $fx3->limit;
        }
        return view('admin.deposits.manual', compact('users','fx1Limit', 'fx2Limit', 'fx3Limit'));
    }
    public function addManualDeposit(Request $request){
        try{
            $request->validate([
                'accountType' => 'required',
                'currency' => 'required',
                'amount' => 'required'
            ]);

            $user = User::query()->where('id', $request->user)->first();

            $cpApi = new \CoinpaymentsAPI(env('CP_PRIVATE_KEY'), env('CP_PUBLIC_KEY'), 'json');
            $depositTransaction = $cpApi->CreateSimpleTransactionWithConversion($request->amount, 'USD', $request->currency, $user->email);

            if($depositTransaction && !is_null($depositTransaction['result'])){
                $status = $cpApi->GetTxInfoSingle($depositTransaction['result']['txn_id']);
                $deposit = new Deposit();
                $deposit->accountType = $request->accountType;
                $deposit->currency = $request->currency;
                $deposit->amount = $request->amount;
                $deposit->userId = $request->user;
                $deposit->transactionId = $depositTransaction['result']['txn_id'];
                $deposit->status = $status['result']['status'];
                if($deposit->save()){
                    $statusUrl = $depositTransaction['result']['status_url'];
                    $transaction = new Transaction();
                    $transaction->type = 'deposit';
                    $transaction->user_id = $request->user;
                    $transaction->amount = $request->amount;
                    $transaction->transaction_id = $depositTransaction['result']['txn_id'];
                    $transaction->status = $status['result']['status'];
                    $transaction->save();
                }
            }

            return $statusUrl;
        } catch (\Exception $e){
            return 0;
        }
    }
}
