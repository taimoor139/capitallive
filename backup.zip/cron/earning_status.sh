#!/bin/sh
cd  /home/u511512799/public_html/ && php artisan earning_percentage:check >> /dev/null 2>&1