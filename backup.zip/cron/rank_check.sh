#!/bin/sh
cd  /home/u511512799/public_html/ && php artisan rank:check >> /dev/null 2>&1