<?php $__env->startSection('content'); ?>
    <style>
        .my-msg-box-msg {
            background-color: rgb(196, 248, 214);
            border-radius: 8px;
            padding: 15px;
            margin-top: 2.5rem !important;
            color: #0C102A;
        }

        .my-msg-box-msg2 {
            background-color: dodgerblue;
            border-radius: 8px;
            padding: 15px;
            margin-top: 2.5rem !important;
            color: #0C102A;
        }
    </style>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card border-top-warning border-bottom-warning">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 text-uppercase fw-bolder">
                                        <h5 class="card-title pb-0"><?php echo e($ticket->category); ?> <span
                                                class="text-warning">|</span>
                                            <?php echo e($ticket->id); ?></h5>
                                        <span class="text-muted">
                                            Ticket # <?php echo e($ticket->ticket_id); ?> <span class="text-warning">|</span>
                                            Status: <?php echo e(($ticket->status == 0 ? "pending" : "close")); ?> <span
                                                class="text-warning">|</span>
                                            <?php echo e(date_format($ticket->created_at, 'M d, Y')); ?>

                                        </span>
                                    </div>
                                    <div class="col-md-6 d-flex justify-content-end align-items-end">
                                        <form method="post"
                                              action="<?php echo e(route('close-ticket', $ticket->ticket_id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-danger btn-sm">Close Ticket</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="main-box">
                                    <div class="main-box-content d-flex mt-1">
                                        <div class="main-box-content-icon">
                                            <img
                                                src="https://ui-avatars.com/api/?name=<?php echo e(str_replace(' ', '+', Auth::user()->name)); ?>&amp;color=7F9CF5&amp;background=EBF4FF"
                                                class="rounded-circle" alt="">
                                        </div>
                                        <div class="main-box-content-name p-1">
                                            <h6 class="m-0"><?php echo e(Auth::user()->name); ?></h6>
                                            <span><?php echo e(date_format($ticket->created_at, 'M d, Y')); ?> ,
                                                <?php
                                                $datetime1 = new DateTime($ticket->created_at);
                                                $datetime2 = new DateTime(date('Y-m-d H:i:s'));
                                                $interval = $datetime1->diff($datetime2);

                                                if ($interval->format('%Y') > 0) {
                                                    echo $interval->format('%Y years');
                                                } else if ($interval->format('%Y') == 0 && $interval->format('%m') > 0) {
                                                    echo $interval->format('%m months');
                                                } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') > 0) {
                                                    echo $interval->format('%d days');
                                                } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') > 0) {
                                                    echo $interval->format('%H hours');
                                                } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') == 0 && $interval->format('%i') > 0) {
                                                    echo $interval->format('%i minutes');
                                                } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') == 0 && $interval->format('%i') == 0 && $interval->format('%s') > 0) {
                                                    echo $interval->format('%s seconds');
                                                } else {
                                                    echo '0 seconds';
                                                }
                                                ?> ago

                                            </span>
                                            <div class="main-box-content-msg pt-3">
                                                <p><?php echo e($ticket->subject); ?></p>
                                            </div>
                                            <?php if($ticket->file): ?>
                                                <a href="<?php echo e(route('download-ticket', $ticket->file)); ?>"
                                                   target="_blank" class="text-danger fw-bolder">
                                                    <img
                                                        src="<?php echo e(public_path()."/uploads/".$ticket->file); ?>"
                                                        class="img-thumbnail ml-3" width="100">
                                                    Attached File
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="card border-top-warning border-bottom-warning">
                            <div class="card-body">
                                <h5 class="card-title pb-0">Message History</h5>
                                <hr>
                                <div class="msg-box">
                                    <?php if($ticket->messages): ?>
                                        <?php $__currentLoopData = $ticket->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div
                                                class="my-msg-box d-flex <?php echo e(($message->user_id == Auth::user()->id ? "flex-row-reverse" : "")); ?> pt-xl-0 pt-lg-0 pt-md-0 pt-4">
                                                <div class="my-msg-box-icon">
                                                    <img
                                                        src="https://ui-avatars.com/api/?name=<?php echo e(str_replace(' ', '+', $message->user_name)); ?>&amp;color=7F9CF5&amp;background=EBF4FF"
                                                        class="rounded-circle" alt="">
                                                </div>
                                                <div class="my-msg-box-name p-1">
                                                    <h6 class="m-0"><?php echo e($message->user_name); ?></h6>
                                                    <span><?php echo e(date_format($message->created_at, 'M d, Y')); ?> ,
                                                <?php
                                                        $datetime1 = new DateTime($message->created_at);
                                                        $datetime2 = new DateTime(date('Y-m-d H:i:s'));
                                                        $interval = $datetime1->diff($datetime2);

                                                        if ($interval->format('%Y') > 0) {
                                                            echo $interval->format('%Y years');
                                                        } else if ($interval->format('%Y') == 0 && $interval->format('%m') > 0) {
                                                            echo $interval->format('%m months');
                                                        } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') > 0) {
                                                            echo $interval->format('%d days');
                                                        } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') > 0) {
                                                            echo $interval->format('%H hours');
                                                        } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') == 0 && $interval->format('%i') > 0) {
                                                            echo $interval->format('%i minutes');
                                                        } else if ($interval->format('%Y') == 0 && $interval->format('%m') == 0 && $interval->format('%d') == 0 && $interval->format('%H') == 0 && $interval->format('%i') == 0 && $interval->format('%s') > 0) {
                                                            echo $interval->format('%s seconds');
                                                        } else {
                                                            echo '0 seconds';
                                                        }
                                                        ?> ago</span>
                                                    <div
                                                        class="<?php echo e(($message->user_id == Auth::user()->id ? "my-msg-box-msg" : "my-msg-box-msg2")); ?> mt-1">
                                                        <?php echo e($message->message); ?>

                                                    </div>
                                                    <?php if($message->file): ?>
                                                        <a href="<?php echo e(route('download-message', $message->file)); ?>"
                                                           target="_blank" class="text-danger fw-bolder">
                                                            <img
                                                                src="<?php echo e(public_path()."/uploads/ticket_attachments/".$message->file); ?>"
                                                                class="img-thumbnail ml-3" width="100">
                                                            Attached File
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($ticket->status == 0): ?>
                        <div class="col-lg-12 ">
                            <div class="card border-top-warning border-bottom-warning">
                                <div class="card-body pt-2">
                                    <form method="post" enctype="multipart/form-data"
                                          action="<?php echo e(route('reply-ticket', $ticket->ticket_id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="msg-box">
                                            <div class="form-floating">
                                <textarea placeholder="Type A New Message" rows="5" class="form-control" name="message"
                                          id="floatingTextarea" style="height: 100px;"></textarea>
                                                <label for="floatingTextarea">Type A New Message</label>
                                            </div>
                                            <input class="form-control mt-3" type="file" name="attachments">
                                            <br>
                                            <button class="btn btn-warning mt-3">Send</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/user/support/view.blade.php ENDPATH**/ ?>