<?php if(Auth::user()->role_id == 1): ?>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Capital Live - Admin Login</title>
        <!-- site favicon -->
        <link rel="shortcut icon" type="image/png"
              href="../../../app-assets/images/ico/apple-icon-120.png">
        <link rel="stylesheet"
              href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&amp;display=swap">
        <!-- bootstrap 4  -->
        <link rel="stylesheet" href="../../../css/grid.min.css">
        <!-- bootstrap toggle css -->
        <link rel="stylesheet" href="../../../css/bootstrap-toggle.min.css">
        <!-- fontawesome 5  -->
        <link rel="stylesheet" href="../../../css/all.min.css">
        <!-- line-awesome webfont -->
        <link rel="stylesheet" href="../../../css/line-awesome.min.css">


        <!-- select 2 css -->
        <link rel="stylesheet" href="../../../css/select2.min.css">
        <!-- jvectormap css -->
        <link rel="stylesheet"
              href="../../../css/jquery-jvectormap-2.0.5.css">
        <!-- datepicker css -->
        <link rel="stylesheet" href="../../../css/datepicker.min.css">
        <!-- timepicky for time picker css -->
        <link rel="stylesheet" href="../../../css/jquery-timepicky.css">
        <!-- bootstrap-clockpicker css -->
        <link rel="stylesheet"
              href="../../../css/bootstrap-clockpicker.min.css">
        <!-- bootstrap-pincode css -->
        <link rel="stylesheet"
              href="../../../css/bootstrap-pincode-input.css">
        <!-- dashdoard main css -->
        <link rel="stylesheet" href="../../../css/app.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


        <style type="text/css">
            @font-face {
                font-weight: 400;
                font-style: normal;
                font-family: 'Circular-Loom';

                src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Book-cd7d2bcec649b1243839a15d5eb8f0a3.woff2') format('woff2');
            }

            @font-face {
                font-weight: 500;
                font-style: normal;
                font-family: 'Circular-Loom';

                src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Medium-d74eac43c78bd5852478998ce63dceb3.woff2') format('woff2');
            }

            @font-face {
                font-weight: 700;
                font-style: normal;
                font-family: 'Circular-Loom';

                src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Bold-83b8ceaf77f49c7cffa44107561909e4.woff2') format('woff2');
            }

            @font-face {
                font-weight: 900;
                font-style: normal;
                font-family: 'Circular-Loom';

                src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Black-bf067ecb8aa777ceb6df7d72226febca.woff2') format('woff2');
            }</style>
    </head>
    <body data-new-gr-c-s-check-loaded="14.1063.0" data-gr-ext-installed="">
    <div class="page-wrapper default-version">
        <div class="form-area bg_img" data-background="../../../img/1.jpg"
             style="background-image: url(&quot;../../../img/1.jpg&quot;);">
            <div class="form-wrapper">
                <a href="/" class="d-flex justify-content-center"><img src="/login.png" alt="Capital first"></a>
                <h3 class="card-text mb-2 uk-text-bold">A fresh verification link has been sent to your email address.</h3>
                <span>Before proceeding, please check your email for a verification link.</span>
                <p class="card-text mb-2">If you did not receive the email</p>
                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('click here to request another')); ?></button>
                </form>
            </div>
        </div><!-- login-area end -->
    </div>


    <!-- jQuery library -->
    <script src="../../../js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap js -->
    <script src="../../../js/bootstrap.bundle.min.js"></script>
    <!-- bootstrap-toggle js -->
    <script src="../../../js/bootstrap-toggle.min.js"></script>
    <!-- slimscroll js for custom scrollbar -->
    <script src="../../../js/jquery.slimscroll.min.js"></script>
    <script src="../../../js/nicEdit.js"></script>
    <!-- seldct 2 js -->
    <script src="../../../js/select2.min.js"></script>

    <link rel="stylesheet" href="../../../css/iziToast.min.css">
    <script src="../../../js/iziToast.min.js"></script>


    <script>
        'use strict';

        function notify(status, message) {
            iziToast[status]({
                message: message,
                position: "topRight"
            });
        }
    </script>

    <script src="https://script.viserlab.com/bisurv/assets/admin/js/app.js"></script>


    <script>
        "use strict";
        (function ($) {
            bkLib.onDomLoaded(function () {
                $(".nicEdit").each(function (index) {
                    $(this).attr("id", "nicEditor" + index);
                    new nicEditor({fullPanel: false}).panelInstance('nicEditor' + index, {hasPanel: true});
                });
            });

            $(document).on('mouseover ', '.nicEdit-main,.nicEdit-panelContain', function () {
                $('.nicEdit-main').focus();
            });
        })(jQuery);
    </script>


    </body>
    <loom-container id="lo-engage-ext-container">
        <loom-shadow classname="resolved"></loom-shadow>
    </loom-container>
    <loom-container id="lo-companion-container">
        <loom-shadow classname="resolved"></loom-shadow>
    </loom-container>
    <grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>
    </html>

<?php else: ?>
<!DOCTYPE html>
<html class="loading dark-layout" lang="en" data-layout="dark-layout" data-textdirection="ltr">
<!-- BEGIN: Head-->

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,user-scalable=0,minimal-ui">
    <meta name="description"
          content="Vuexy admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords"
          content="admin template, Vuexy admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>Email Verification - Capital First</title>
    <link rel="apple-touch-icon" href="../../../app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="Background.png">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;1,400;1,500;1,600"
          rel="stylesheet">

    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/vendors/css/vendors.min.css">
    <!-- END: Vendor CSS-->

    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/colors.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/components.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/themes/bordered-layout.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/themes/semi-dark-layout.css">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/plugins/forms/form-validation.css">
    <link rel="stylesheet" type="text/css" href="../../../app-assets/css/pages/page-auth.css">
    <!-- END: Page CSS-->

    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../../assets/css/style.css">
    <!-- END: Custom CSS-->

</head>
<!-- END: Head-->

<!-- BEGIN: Body-->

<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static  " data-open="click"
      data-menu="vertical-menu-modern" data-col="blank-page">
<!-- BEGIN: Content-->
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body">
            <div class="auth-wrapper auth-v1 px-2">
                <div class="auth-inner py-2">
                    <!-- Login v1 -->
                    <div class="card mb-0">
                        <div class="card-body">
                            <a href="/" class="d-flex justify-content-center"><img src="/login.png" alt="Capital first"></a>
                            <h3 class="card-text mb-2 uk-text-bold">A fresh verification link has been sent to your email address.</h3>
                            <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                            <?php echo e(__('If you did not receive the email')); ?>,
                            <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-primary btn-block"><?php echo e(__('click here to request another')); ?></button>
                            </form>
                        </div>
                    </div>
                    <!-- /Login v1 -->
                </div>
            </div>

        </div>
    </div>
</div>
<!-- END: Content-->


<!-- BEGIN: Vendor JS-->
<script src="../../../app-assets/vendors/js/vendors.min.js"></script>
<!-- BEGIN Vendor JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="../../../app-assets/vendors/js/forms/validation/jquery.validate.min.js"></script>
<!-- END: Page Vendor JS-->

<!-- BEGIN: Theme JS-->
<script src="../../../app-assets/js/core/app-menu.js"></script>
<script src="../../../app-assets/js/core/app.js"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page JS-->
<script src="../../../app-assets/js/scripts/pages/page-auth-login.js"></script>
<!-- END: Page JS-->

<script>
    $(window).on('load', function() {
        if (feather) {
            feather.replace({
                width: 14,
                height: 14
            });
        }
    })
</script>
<script>
    <?php if(Session::has('success')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

        <?php if(Session::has('error')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

        <?php if(Session::has('info')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

        <?php if(Session::has('warning')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>
</body>
<!-- END: Body-->

</html>
<?php endif; ?>
<?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/auth/verify.blade.php ENDPATH**/ ?>