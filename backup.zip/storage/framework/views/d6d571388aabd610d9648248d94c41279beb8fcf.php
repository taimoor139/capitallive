<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capital Live - Admin Login</title>
    <!-- site favicon -->
    <link rel="shortcut icon" type="image/png"
          href="../../../app-assets/images/ico/apple-icon-120.png">
    <link rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&amp;display=swap">
    <!-- bootstrap 4  -->
    <link rel="stylesheet" href="../../../css/grid.min.css">
    <!-- bootstrap toggle css -->
    <link rel="stylesheet" href="../../../css/bootstrap-toggle.min.css">
    <!-- fontawesome 5  -->
    <link rel="stylesheet" href="../../../css/all.min.css">
    <!-- line-awesome webfont -->
    <link rel="stylesheet" href="../../../css/line-awesome.min.css">


    <!-- select 2 css -->
    <link rel="stylesheet" href="../../../css/select2.min.css">
    <!-- jvectormap css -->
    <link rel="stylesheet"
          href="../../../css/jquery-jvectormap-2.0.5.css">
    <!-- datepicker css -->
    <link rel="stylesheet" href="../../../css/datepicker.min.css">
    <!-- timepicky for time picker css -->
    <link rel="stylesheet" href="../../../css/jquery-timepicky.css">
    <!-- bootstrap-clockpicker css -->
    <link rel="stylesheet"
          href="../../../css/bootstrap-clockpicker.min.css">
    <!-- bootstrap-pincode css -->
    <link rel="stylesheet"
          href="../../../css/bootstrap-pincode-input.css">
    <!-- dashdoard main css -->
    <link rel="stylesheet" href="../../../css/app.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


    <style type="text/css">
        @font-face {
            font-weight: 400;
            font-style: normal;
            font-family: 'Circular-Loom';

            src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Book-cd7d2bcec649b1243839a15d5eb8f0a3.woff2') format('woff2');
        }

        @font-face {
            font-weight: 500;
            font-style: normal;
            font-family: 'Circular-Loom';

            src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Medium-d74eac43c78bd5852478998ce63dceb3.woff2') format('woff2');
        }

        @font-face {
            font-weight: 700;
            font-style: normal;
            font-family: 'Circular-Loom';

            src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Bold-83b8ceaf77f49c7cffa44107561909e4.woff2') format('woff2');
        }

        @font-face {
            font-weight: 900;
            font-style: normal;
            font-family: 'Circular-Loom';

            src: url('https://cdn.loom.com/assets/fonts/circular/CircularXXWeb-Black-bf067ecb8aa777ceb6df7d72226febca.woff2') format('woff2');
        }</style>
</head>
<body data-new-gr-c-s-check-loaded="14.1063.0" data-gr-ext-installed="">
<div class="page-wrapper default-version">
    <div class="form-area bg_img" data-background="../../../img/1.jpg"
         style="background-image: url(&quot;../../../img/1.jpg&quot;);">
        <div class="form-wrapper">
            <h4 class="logo-text mb-15">Welcome to <strong>Capital Live</strong></h4>
            <p>Admin Login to Capital Live dashboard</p>
            <form action="<?php echo e(route('login')); ?>" method="POST" class="cmn-form mt-30">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Username</label>
                    <input type="text" name="email" class="form-control b-radius--capsule" id="email"
                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>" required
                    autocomplete="email" autofocus />
                    <i class="fa fa-user input-icon"></i>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                </div>
                <div class="form-group">
                    <label for="pass">Password</label>
                    <input type="password" name="password" class="form-control b-radius--capsule" id="password"
                           <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                    autocomplete="current-password" />
                    <i class="fa fa-lock input-icon"></i>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                </div>
                <div class="form-group d-flex justify-content-between align-items-center">
                    <a href="<?php echo e(route('admin-reset-password')); ?>" class="text-muted text--small"><i
                            class="fa fa-lock"></i>Forgot password?</a>
                </div>
                <!--<p class="text-center mt-2">-->
                <!--    <span>New on our platform?</span>-->
                <!--    <a href="<?php echo e(route('admin-register')); ?>" >-->
                <!--       Create an account-->
                <!--    </a>-->
                <!--</p>-->
                <div class="form-group">
                    <button type="submit" class="submit-btn mt-25 b-radius--capsule">Login <i
                            class="fa fa-sign-in"></i></button>
                </div>
            </form>
        </div>
    </div><!-- login-area end -->
</div>


<!-- jQuery library -->
<script src="../../../js/jquery-3.6.0.min.js"></script>
<!-- bootstrap js -->
<script src="../../../js/bootstrap.bundle.min.js"></script>
<!-- bootstrap-toggle js -->
<script src="../../../js/bootstrap-toggle.min.js"></script>
<!-- slimscroll js for custom scrollbar -->
<script src="../../../js/jquery.slimscroll.min.js"></script>
<script src="../../../js/nicEdit.js"></script>
<!-- seldct 2 js -->
<script src="../../../js/select2.min.js"></script>

<link rel="stylesheet" href="../../../css/iziToast.min.css">
<script src="../../../js/iziToast.min.js"></script>

<!-- 
<script>
    
    'use strict';

    function notify(status, message) {
        <?php if(Session::has('error')): ?>
        iziToast[status]({
            message: <?php echo e(session('error')); ?>,
            position: "topRight"
        });
        <?php endif; ?>
    }
</script> -->

<script>
        'use strict';
        <?php if(Session::has('status')): ?>
                iziToast.error({
            message: "<?php echo e(session('status')); ?>",
            position: "topRight"
        });
        <?php endif; ?>
            </script>

<script src="https://script.viserlab.com/bisurv/assets/admin/js/app.js"></script>


<script>
    "use strict";
    (function ($) {
        bkLib.onDomLoaded(function () {
            $(".nicEdit").each(function (index) {
                $(this).attr("id", "nicEditor" + index);
                new nicEditor({fullPanel: false}).panelInstance('nicEditor' + index, {hasPanel: true});
            });
        });

        $(document).on('mouseover ', '.nicEdit-main,.nicEdit-panelContain', function () {
            $('.nicEdit-main').focus();
        });
    })(jQuery);
</script>

<script>
        <?php if(Session::has('status')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.success("<?php echo e(session('status')); ?>");
        <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
</body>
<loom-container id="lo-engage-ext-container">
    <loom-shadow classname="resolved"></loom-shadow>
</loom-container>
<loom-container id="lo-companion-container">
    <loom-shadow classname="resolved"></loom-shadow>
</loom-container>
<grammarly-desktop-integration data-grammarly-shadow-root="true"></grammarly-desktop-integration>
</html>
<?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/auth/admin/login.blade.php ENDPATH**/ ?>