

<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row">
                <div class="col-lg-12">
                    <div class="col-lg-6 col-sm-6">
                        <h6 class="page-title">Support Tickets</h6>
                    </div>
                    <table id="table" class="table table--light style--two">
                        <thead>
                        <tr>
                            <th scope="col">Subject</th>
                            <th scope="col">Submitted By</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('views-ticket', $ticket->id)); ?>">[Ticket#<?php echo e($ticket->ticket_id); ?>] <?php echo e($ticket->subject); ?></a></td>
                                <td><a href="<?php echo e(route('view-user', $ticket->user_id)); ?>"><?php echo e($ticket->users->username); ?></a></td>
                                <td><span class="<?php echo e(($ticket->status == 0 ? 'text-success' : 'text-danger')); ?>"><?php echo e(($ticket->status == 0 ? 'Active' : 'Close')); ?></span></td>
                                <td>
                                    <button data-id="<?php echo e($ticket->ticket_id); ?>" type="button" data-toggle="modal" data-target="#DelTicket"
                                            class="btn btn-danger btn-sm my-3 delete-ticket"><i
                                                class="fa fa-trash"></i> Delete
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table><!-- table end -->
                </div>
                <div class="modal fade" id="DelTicket" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                     aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Delete Reply!</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <strong>Are you sure to delete this?</strong>
                            </div>
                            <div class="modal-footer">
                                <form method="post" action="<?php echo e(route('delete-ticket')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="ticket_id" class="ticket_id">
                                    <button type="button" class="btn btn--dark" data-dismiss="modal">No</button>
                                    <button type="submit" class="btn btn--danger"><i class="fa fa-trash"></i> Delete
                                    </button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- bodywrapper__inner end -->
    </div><!-- body-wrapper end -->

    <script>
        'use strict';
        (function ($) {
            $('.delete-ticket').on('click', function (e) {
                $('.ticket_id').val($(this).data('id'));
            });
        })(jQuery)
    </script>
    <script>

        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

                <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

                <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

                <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/support/index.blade.php ENDPATH**/ ?>