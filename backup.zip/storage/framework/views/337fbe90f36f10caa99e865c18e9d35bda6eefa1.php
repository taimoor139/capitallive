<div class="main-menu  menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
    <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">
            <li class="nav-item mr-auto"><a class="navbar-brand"
                    href="../../../html/ltr/vertical-menu-template-dark/index.html">
                    
                        <a class="nav-link" href="<?php echo e(route('user.dashboard')); ?>"
                        data-toggle="tooltip" data-placement="top" title="Email"> Capital First </a>
                </a></li>
            <li class="nav-item nav-toggle"><a class="nav-link modern-nav-toggle pr-0" data-toggle="collapse"><i
                        class="d-block d-xl-none text-primary toggle-icon font-medium-4" data-feather="x"></i><i
                        class="d-none d-xl-block collapse-toggle-icon font-medium-4  text-primary" data-feather="disc"
                        data-ticon="disc"></i></a></li>
        </ul>
    </div>
    <div class="shadow-bottom"></div>
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('user.dashboard')); ?>"><i
                        data-feather="grid"></i><span class="menu-title text-truncate"
                        data-i18n="Dashboards">Dashboard</span></a>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                        data-feather="dollar-sign"></i><span class="menu-title text-truncate" data-i18n="Invoice">My
                        Money</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('deposit-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="List">Deposits</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('withdrawal-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="Preview">Withdrawals</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                        data-feather="file-text"></i><span class="menu-title text-truncate"
                        data-i18n="Invoice">Accounts</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('account-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Bonus
                                Accounts</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('earning-accounts')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="Preview">Earning Accounts</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="share-2"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Network</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('network-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="List">Genealogy</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                        data-feather="bar-chart"></i><span class="menu-title text-truncate"
                        data-i18n="Invoice">Awards</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('award-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Rank
                                Awards</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('executive-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="Preview">Executive Awards</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="list"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">My
                        Documents</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('document-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">KYC
                                Documents</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i data-feather="user"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Profile</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('profile-dashboard')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">My
                                Profile</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('security')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate"
                                data-i18n="List">Security</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('nextOfKin')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Next Of
                                Kin</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('refferals')); ?>"><i data-feather="link"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Referrals</span></a>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('trade-activation')); ?>"><i data-feather="link"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Trade
                        Activation</span></a>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="#"><i
                        data-feather="help-circle"></i><span class="menu-title text-truncate"
                        data-i18n="Invoice">Support</span></a>
                <ul class="menu-content">
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('new-ticket')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">Create
                                New Ticket</span></a>
                    </li>
                    <li><a class="d-flex align-items-center" href="<?php echo e(route('tickets')); ?>"><i
                                data-feather="circle"></i><span class="menu-item text-truncate" data-i18n="List">My
                                Tickets</span></a>
                    </li>
                </ul>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('download')); ?>"><i
                        data-feather="download"></i><span class="menu-title text-truncate"
                        data-i18n="Invoice">Downloads</span></a>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('education')); ?>"><i data-feather="book"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Education</span></a>
            </li>

            <li class=" nav-item"><a class="d-flex align-items-center" href="<?php echo e(route('suggestions')); ?>"><i data-feather="mail"></i><span
                        class="menu-title text-truncate" data-i18n="Invoice">Suggestions</span></a>
            </li>

        </ul>
    </div>
</div>
<?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/layouts/user/partials/sidebar.blade.php ENDPATH**/ ?>