<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>rer</title>
</head>
<body>
<h1>rere</h1>
<p>rererer</p>
</body>
</html><?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/admin/users/mail.blade.php ENDPATH**/ ?>