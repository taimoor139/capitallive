

<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">
            <form action="<?php echo e(route('store-subadmin')); ?>">
                <div class="col-md-12 card">
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 pt-2">
                            <h6 class="page-title">Create SubAdmin</h6>
                            <hr>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" id="email" name="email">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            <div class="form-group">
                                <label for="confirm_password">Confirm Password</label>
                                <input type="password" class="form-control" id="confirm_password"
                                       name="confirm_password">
                            </div>
                            <div id="passwordCheck">

                            </div>
                            <hr>
                            <h6 class="page-title">Roles</h6>
                            <hr>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>"> <?php echo e($role->name); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <br>
                            <div class=" pb-4">
                                <button type="submit" class="btn btn--info">Create</button>
                            </div>
                        </div>
                        <div class="col-md-3"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        $('#confirm_password').keyup(function (){
            var password = $('#password').val();

            if(password != $(this).val()){
                $('#passwordCheck').html('<span  class="alert-danger">Passwords did not matched!</span>');
            } else {
                $('#passwordCheck').html('<span  class="alert-success">Passwords matched!</span>');
            }
        })

        $('#password').keyup(function (){
            var cPassword = $('#confirm_password').val();

            if(cPassword && cPassword != $(this).val()){
                $('#passwordCheck').html('<span  class="alert-danger">Passwords did not matched!</span>');
            } else if(cPassword && cPassword == $(this).val()){
                $('#passwordCheck').html('<span  class="alert-success">Passwords matched!</span>');
            }
        })
    </script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

                <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

                <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

                <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/admin/subadmin/create.blade.php ENDPATH**/ ?>