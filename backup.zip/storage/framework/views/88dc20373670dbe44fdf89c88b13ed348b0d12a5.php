<div class="modal fade " id="changeProfilePicture" tabindex="-1" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content border-top-warning border-bottom-warning">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-currency-exchange text-danger"></i> Change Profile Picture</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" id="withdrawForm" action="<?php echo e(route('change-dp')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 mt-3">
                            <div class="form-group">
                                <label for="currency">Select Currency</label>
                                <input type="file" id="img" name="img" accept="image/*" class="form-control" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning processBtn" data-value="Proceed">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    <?php if(Session::has('success')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.success("<?php echo e(session('success')); ?>");
    <?php endif; ?>

        <?php if(Session::has('error')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

        <?php if(Session::has('info')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

        <?php if(Session::has('warning')): ?>
        toastr.options =
        {
            "closeButton" : true,
            "progressBar" : true
        }
    toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>
<?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/user/profile/changeProfilePic.blade.php ENDPATH**/ ?>