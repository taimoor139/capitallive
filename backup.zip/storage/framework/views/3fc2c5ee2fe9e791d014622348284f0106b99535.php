<nav class="navbar-wrapper  navbar navbar-expand-lg">
    <form class="navbar-search" onsubmit="return false;">
        <button type="submit" class="navbar-search__btn">
            <i class="las la-search"></i>
        </button>
        <input type="search" name="navbar-search__field" id="navbar-search__field" placeholder="Search...">
        <button type="button" class="navbar-search__close"><i class="fa fa-times"></i></button>

        <div id="navbar_search_result_area">
            <ul class="navbar_search_result"></ul>
        </div>
    </form>

    <div class="navbar__left">
        <button class="res-sidebar-open-btn"><i class="fa fa-bars"></i></button>
    </div>

    <div class="navbar__right">
        <ul class="navbar__action-list">
            <li class="dropdown">
                <button type="button" class="" data-toggle="dropdown" data-display="static" aria-haspopup="true" aria-expanded="false">

                    <span class="navbar-user">
                        <span class="navbar-user__thumb">
                            <?php if(Auth::user()->image): ?>
                                <img
                                        class="round"
                                        src="<?php echo e(url('/uploads/profile_pictures/'.Auth::user()->image)); ?>"
                                        alt="avatar" height="40" width="40">
                            <?php else: ?>
                                <img
                                        class="round"
                                        src="https://ui-avatars.com/api/?name=<?php echo e(str_replace(' ', '+', Auth::user()->name)); ?>&amp;color=7F9CF5&amp;background=EBF4FF"
                                        alt="avatar" height="40" width="40">
                            <?php endif; ?>
                        </span>

                        <span class="navbar-user__info">
                        <span class="navbar-user__name"><?php echo e(Auth::user()->name); ?></span>
                        </span>
                        <span class="icon"><i class="fa fa-chevron-circle-down"></i></span>
                    </span>
                </button>

                <div class="dropdown-menu dropdown-menu--sm p-0 border-0 box--shadow1 dropdown-menu-right">
                    <a href="<?php echo e(route('view-profile')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                        <i class="dropdown-menu__icon fa fa-user-circle"></i>
                        <span class="dropdown-menu__caption">Profile</span>
                    </a>

                    <a href="<?php echo e(route('updateAdminPassword')); ?>" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                        <i class="dropdown-menu__icon fa fa-key"></i>
                        <span class="dropdown-menu__caption">Password</span>
                    </a>

                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();" class="dropdown-menu__item d-flex align-items-center px-3 py-2">
                        <i class="dropdown-menu__icon fa fa-sign-in-alt"></i>
                        <span class="dropdown-menu__caption">Logout</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/layouts/admin/partials/header.blade.php ENDPATH**/ ?>