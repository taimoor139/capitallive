<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row align-items-center mb-30 justify-content-between">
                <div class="col-lg-6 col-sm-6">
                    <h6 class="page-title">Profile</h6>
                </div>
                <div class="col-lg-6 col-sm-6 text-sm-right mt-sm-0 mt-3 right-part">
                    <a href="<?php echo e(route('updateAdminPassword')); ?>"
                       class="btn btn-sm btn--primary box--shadow1 text--small"><i class="fa fa-key"></i>Password
                        Setting</a>
                </div>
            </div>

            <div class="row mb-none-30">
                <div class="col-lg-3 col-md-3 mb-30">
                    <div class="card b-radius--5 overflow-hidden">
                        <div class="card-body p-0">
                            <div class="d-flex p-3 bg--primary align-items-center">
                                <div class="avatar avatar--lg">

                                    <?php if(Auth::user()->image): ?>

                                        <img src="/uploads/profile_pictures/<?php echo e(Auth::user()->image); ?>"
                                             alt="Image">
                                    <?php else: ?>

                                        <img src="https://script.viserlab.com/bisurv/assets/images/avatar.png"
                                             alt="Image">
                                    <?php endif; ?>
                                </div>
                                <div class="pl-3">
                                    <h4 class="text--white"><?php echo e(Auth::user()->name); ?></h4>
                                </div>
                            </div>
                            <ul class="list-group">
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Name <span class="font-weight-bold"><?php echo e(Auth::user()->name); ?></span>
                                </li>

                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Username <span class="font-weight-bold"><?php echo e(Auth::user()->username); ?></span>
                                </li>

                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    Email <span class="font-weight-bold"><?php echo e(Auth::user()->email); ?></span>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-md-9 mb-30">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title mb-50 border-bottom pb-2">Profile Information</h5>
                            <form action="<?php echo e(route('profile-update')); ?>" method="POST"
                                  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">

                                    <div class="col-md-6">

                                        <div class="form-group">
                                            <div class="image-upload">
                                                <div class="thumb">
                                                    <div class="avatar-preview">
                                                        <?php if(Auth::user()->image): ?>
                                                            <div class="profilePicPreview"
                                                                 style="background-image: url('/uploads/profile_pictures/<?php echo e(Auth::user()->image); ?>')">
                                                                <button type="button" class="remove-image"><i
                                                                            class="fa fa-times"></i></button>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="profilePicPreview"
                                                                 style="background-image: url('https://script.viserlab.com/bisurv/assets/images/avatar.png')">
                                                                <button type="button" class="remove-image"><i
                                                                            class="fa fa-times"></i></button>
                                                            </div>
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="avatar-edit">
                                                        <input type="file" class="profilePicUpload" name="img"
                                                               id="profilePicUpload1" accept=".png, .jpg, .jpeg" >
                                                        <label for="profilePicUpload1" class="bg--success">Upload
                                                            Image</label>
                                                        <small class="mt-2 text-facebook">Supported files: <b>jpeg,
                                                                jpg.</b> Image will be resized into 400x400px
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group ">
                                            <label class="form-control-label font-weight-bold">Name</label>
                                            <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label class="form-control-label  font-weight-bold">Email</label>
                                            <input class="form-control" type="email" name="email"
                                                   value="<?php echo e(Auth::user()->email); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn--primary btn-block btn-lg">Save Changes
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


        </div><!-- bodywrapper__inner end -->
    </div>

    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

                <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

                <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

                <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/profile/myProfile.blade.php ENDPATH**/ ?>