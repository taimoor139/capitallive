<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">


                <div class="row">
                    <div class="col-xl-6 col-sm-6 mb-20">
                        <div class="card border-top-warning border-bottom-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4"><?php echo e($totalLeftMembers); ?></h5>
                                <p class="card-text"><i class="bi bi-diagram-2 text-danger"></i> <b>LEFT</b>
                                    <small>Referrals</small>
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-sm-6 mb-20">
                        <div class="card border-top-warning border-bottom-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4"><?php echo e($totalRightMembers); ?></h5>
                                <p class="card-text"><i class="bi bi-diagram-2 text-danger"></i> <b>RIGHT</b>
                                    <small>Referrals</small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="col-md-12 pt-3">
                            <div class="row">
                                <div class=" col-md-6">
                                    <div class="main-box">
                                        <div class="main-box-content d-flex justify-content-between">
                                            <div class="left d-flex">
                                                <div class="main-box-content-icon">
                                                    <i class="bi bi-link-45deg text-danger"></i>
                                                </div>
                                                <div class="main-box-content-name">
                                                    <h6 class="m-0">Referral Link</h6>
                                                    <a href="#"
                                                       class="text-primary text-decoration-underline copyBtn"><?php echo e(url('/register/'.Auth::user()->username)); ?></a>
                                                </div>
                                            </div>
                                            <div class="copy-btn mt-2">
                                                <button class="btn btn-sm btn-outline-warning copy_btn"
                                                        onclick="copyReferralLink()"
                                                        data-clipboard-text="<?php echo e(url('/register/'.Auth::user()->username)); ?>">
                                                    Copy
                                                    Link
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="main-box">
                                        <form method="post" class="m-0"
                                              action="<?php echo e(route('set-position')); ?>">
                                            <div class="main-box-content d-flex justify-content-between">
                                                <?php echo csrf_field(); ?>
                                                <div class="d-flex">
                                                    <div class="main-box-content-icon">
                                                        <i class="bi bi-link-45deg text-danger"></i>
                                                    </div>
                                                    <div class="main-box-content-name">
                                                        <h6 class="m-0">Position</h6>
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <div class="form-check">
                                                                    <input class="form-check-input" type="radio"
                                                                           name="position" value="0" id="positionLEFT"
                                                                        <?php echo e(($position == 0 ? 'checked':'')); ?>>
                                                                    <label class="form-check-label"
                                                                           for="positionLEFT">LEFT</label>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <div class="form-check">
                                                                    <input class="form-check-input " type="radio"
                                                                           name="position" value="1"
                                                                           id="positionRIGHT" <?php echo e(($position == 1 ? 'checked':'')); ?>>
                                                                    <label class="form-check-label"
                                                                           for="positionRIGHT">RIGHT</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="copy-btn mt-2">
                                                    <button class="btn btn-sm btn-warning">Save</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer border-top-warning">
                        <h4 class="card-title">Direct Sponsors</h4>
                        <table class="table table-striped" id="dataTable">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Position</th>
                                <th scope="col">Joining Date</th>
                                <th scope="col">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $sponsors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td class="text-center"><?php echo e($sponsor->user->name ?? ''); ?></td>
                                    <td><?php echo e(($sponsor->position == 0 ?'Left':'Right')); ?></td>
                                    <td><?php echo e(date_format($sponsor->created_at, 'd-m-Y')); ?></td>
                                    <?php if($sponsor->deposit): ?>
                                        <td><?php echo e(($sponsor->deposit->status == 100 ? 'Payment Done' : 'Waiting for approval')); ?></td>
                                    <?php else: ?>
                                        <td>No Deposit has been made</td>
                                    <?php endif; ?>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </div>
    <script>
        function copyReferralLink() {
            navigator.clipboard.writeText($('.copy_btn').attr('data-clipboard-text'));
            $('.copy_btn').text('Copied!')
        }

    </script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/user/refferals/refferals.blade.php ENDPATH**/ ?>