<?php echo e($slot); ?>

<?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>