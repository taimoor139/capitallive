

<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row">
                <div class="col-lg-12">
                    <div class="col-lg-6 col-sm-6">
                        <h6 class="page-title">Add Manual Deposit</h6>
                    </div>
                </div>
            </div>
            <form action="#" id="depositForm" method="post">
                <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
                <div class="row">
                    <div class="container">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="user">User</label>
                                <select class="form-control" id="user" name="user" required>
                                    <option>Select User</option>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="currency">Account Type</label>
                                <select class="form-control" name="accountType" id="account_type" required>
                                    <option hidden value="">Please Select</option>
                                    <option value="1"> CF Standard Account 50$
                                    </option>
                                    <option value="2"> CF Pro Account 500$
                                    </option>
                                    <option value="3"> CF Brokerage Account 1000$
                                    </option>
                                </select>
                                <span class="text-danger error error_account_type d-none d-none"></span>
                            </div>
                            <div class="form-group">
                                <label for="currency">Select Currency</label>
                                <select class="form-control" name="currency" id="currency" required>
                                    <option hidden value="">Please Select</option>
                                    <option value="BTC">
                                        BTC - BTC
                                    </option>
                                    <option value="USDT.TRC20">
                                        USDT - USDT.TRC20
                                    </option>
                                </select>
                                <span class="text-danger error error_currency d-none d-none"></span>
                            </div>
                            <div class="form-group">
                                <label for="amount">Enter Amount
                                    <small class="text-muted">USD</small>
                                </label>
                                <input type="number" class="form-control" name="amount" id="amount"
                                       placeholder="Enter USD" required>
                                <p class="text-danger error error_amount error_coin d-none d-none"></p>
                                <span id="amount-warning" class="alert-warning"></span>
                            </div>

                            <span id="amount-warning" class="alert-warning"></span>

                            <button type="submit" class="btn btn-info float-right processBtn">Submit</button>
                        </div>

                        <div class="col-md-2"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script>
        $('#account_type').change(function () {

            var amount = $('#amount').val();
            var accountType = $(this).val();

            if (accountType == 1 && amount < <?php echo e($fx1Limit); ?>) {
                $('#amount-warning').html('The amount must be at least <?php echo e($fx1Limit); ?>.');
                $('.processBtn').prop('disabled', true);
            } else if (accountType == 2 && amount < <?php echo e($fx2Limit); ?>) {
                $('#amount-warning').html('The amount must be at least <?php echo e($fx2Limit); ?>.');
                $('.processBtn').prop('disabled', true);
            } else if (accountType == 3 && amount < <?php echo e($fx3Limit); ?>) {
                $('#amount-warning').html('The amount must be at least <?php echo e($fx3Limit); ?>.');
                $('.processBtn').prop('disabled', true);
            } else {
                $('.processBtn').prop('disabled', false);
            }
        });
        $('#depositForm').on('submit', function (e) {
            e.preventDefault();
            $('.processBtn').prop('disabled', true);

            var amount = $('#amount').val();
            var user = $('#user').val();
            var currency = $('#currency').val();
            var accountType = $('#account_type').val();
            var _token = $('#_token').val();

            $.ajax({
                url: "<?php echo e(route('add-manual-deposit')); ?>",
                type: "POST",
                data: {
                    _token: _token,
                    user:user,
                    amount: amount,
                    currency: currency,
                    accountType: accountType
                },
                success: function (response) {
                    console.log(response)
                    if (response) {
                        window.open(response);
                        location.reload();
                    } else {
                        $('#deposit-warning').html('Something went Wrong!');
                        setTimeout(function () {
                            location.reload();
                        }, 5000);
                    }
                }
            })
        });
    </script>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

                <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

                <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

                <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/deposits/manual.blade.php ENDPATH**/ ?>