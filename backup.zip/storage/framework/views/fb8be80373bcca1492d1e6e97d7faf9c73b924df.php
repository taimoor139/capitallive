<?php echo e($slot); ?>

<?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>