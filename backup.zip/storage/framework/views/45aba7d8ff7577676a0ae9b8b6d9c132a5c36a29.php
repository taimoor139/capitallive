<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <div class="row justify-content-center">
                    <div class="card border-top-warning border-bottom-warning">
                        <div class="card-body">
                            <h5 class="card-title"><i class="bi bi-award"></i>Support <a href="<?php echo e(route('new-ticket')); ?>" class="btn btn-warning float-right text-uppercase">New Ticket</a>
                                <br>
                                <small>Open ticket for any issues related to your account. Our team will get back to you soon.</small>
                            </h5>

                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Ticket ID</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Created At</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($ticket->file): ?>
                                            <td>
                                                <a href="<?php echo e(route('download-ticket', $ticket->file)); ?>"
                                                   target="_blank" class="fw-bolder">
                                                    Attached File
                                                </a>
                                            </td>
                                        <?php else: ?>
                                            <td>
                                                <a href="<?php echo e(route('tickets')); ?>" class="fw-bolder">
                                                    Attached File
                                                </a>
                                            </td>
                                        <?php endif; ?>

                                        <td><?php echo e($ticket->category ?? ''); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('view-ticket',$ticket->ticket_id)); ?>"><?php echo e($ticket->subject ?? ''); ?></a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('view-ticket',$ticket->ticket_id)); ?>"><?php echo e($ticket->ticket_id); ?></a>
                                        </td>
                                        <td><?php echo e(($ticket->status == 0 ? "Pending" : "Closed")); ?></td>
                                        <td>
                                            <?php echo e($ticket->created_at); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton" : true,
                "progressBar" : true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/user/support/index.blade.php ENDPATH**/ ?>