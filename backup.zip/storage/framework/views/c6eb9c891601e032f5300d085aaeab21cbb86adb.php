

<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row">
                <div class="col-lg-12">
                    
                    
                    
                    <div class="col-lg-6 col-sm-6">
                        <h6 class="page-title">Banned Users</h6>
                    </div>
                    <table id="table" class="table table--light style--two">
                        <thead>
                        <tr>
                            <th scope="col">User</th>
                            <th scope="col">Username</th>
                            <th scope="col">Email</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Type</th>
                            <th scope="col">Joined At</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $bannedUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><a href="<?php echo e(route('view-user', $user->id)); ?>"><?php echo e($user->username); ?></a></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->number ?? 'N/A'); ?></td>
                                <td><?php echo e(($user->role_id == 1 ? 'Admin' : 'User')); ?></td>
                                <td><?php echo e(date_format($user->created_at, 'd-m-Y')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table><!-- table end -->
                </div>
                
                
                

            </div>
        </div><!-- bodywrapper__inner end -->
    </div><!-- body-wrapper end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/users/banned.blade.php ENDPATH**/ ?>