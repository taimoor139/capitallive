<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <div class="row justify-content-center">
                    <div class="col-12">
                        <div class="card border-top-warning border-bottom-warning">
                            <div class="card-body">
                                <h5 class="card-title"><i class="bi bi-currency-exchange text-primary"></i> My Deposits
                                    
                                    <a href="#" class="btn btn-primary float-right" data-toggle="modal"
                                       data-target="#addDeposit">New Deposit</i></a>
                                    <?php echo $__env->make('user.deposit.addDeposit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </h5>
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Account Type</th>
                                        <th scope="col">Currency</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Date</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($loop->iteration); ?>

                                            </td>

                                            <?php if($deposit->accountType == 1): ?>
                                                <td>3X Factor</td>
                                            <?php elseif($deposit->accountType == 2): ?>
                                                <td>2X Level</td>
                                            <?php else: ?>
                                                <td>3X Level</td>
                                            <?php endif; ?>

                                            <td>
                                                <?php if($deposit->currency == 'BTC'): ?>
                                                    <img src="<?php echo e(asset('img/btc.svg')); ?>"
                                                         class="img-fluid rounded-circle" width="30px" alt="">
                                                    <span><?php echo e($deposit->currency); ?></span>
                                                <?php endif; ?>




                                                <?php if($deposit->currency == 'USDT.TRC20'): ?>
                                                    <img src="<?php echo e(asset('img/usdt.svg')); ?>"
                                                         class="img-fluid rounded-circle" width="30px" alt="">
                                                        <span>USDT</span>
                                                <?php endif; ?>






                                                <small class="text-md font-weight-bolder"><?php echo e($deposit->amount); ?> <span
                                                        class="text-muted">USD</span></small>
                                            </td>
                                            <td>
                                                <?php echo e($deposit->paymentStatus->name); ?>

                                                <br>
                                                <small><?php echo e($deposit->transactionId); ?>

                                                </small>
                                            </td>

                                            <td><?php echo e(date_format($deposit->created_at, 'M d, Y - h:i')); ?></td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/user/deposit/deposit.blade.php ENDPATH**/ ?>