<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\upwork\php\pakistan\mlm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>