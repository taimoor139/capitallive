<br><br>
Hi <?php echo e($name); ?>,<br>

User details: <br><br>



Name:  <?php echo e($name); ?><br>

 Email:  <?php echo e($email); ?><br>

 Subject:  <?php echo e($subject); ?><br>

<?php echo $data; ?><br><br>


<?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/email/contactMail.blade.php ENDPATH**/ ?>