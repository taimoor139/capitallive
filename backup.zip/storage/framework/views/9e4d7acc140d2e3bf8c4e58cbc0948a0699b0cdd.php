<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <div class="row">
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">Earning Account</h5>
                                <p class="card-text">Statistics <i class="bi bi-clipboard-data text-danger"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">$ <?php echo e(round($monthlyEarning, 2)); ?></h5>
                                <p class="card-text">This Month <i class="bi bi-person-lines-fill text-primary"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">$ <?php echo e(round($totalEarning, 2)); ?></h5>
                                <p class="card-text">Total Earning <i class="bi bi-diagram-2 text-primary"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">

                                <h5 class="card-title p-0 pt-4">
                                    $ <?php echo e(round($currentEarning, 4)); ?>

                                    <?php if($currentEarning > 10): ?>
                                        <small><a
                                                href="<?php echo e(route('move-earning')); ?>">Move</a></small>
                                    <?php endif; ?>
                                </h5>
                                <p class="card-text">Pending <i class="bi bi-unlock-fill text-danger">
                                        Minimum: 10$ </i></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-top-warning  border-bottom-warning">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-currency-dollar text-danger"></i> Earning Account</h5>
                        <table class="table table-hover" id="table">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Date</th>
                                <th scope="col">Amount</th>
                                <th scope="col">Percentage</th>
                                <th scope="col">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $earnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(date_format($earning->created_at, 'Y-m-d')); ?></td>
                                    <td><?php echo e(round($earning->earning, 4)); ?></td>
                                    <td><?php echo e($earning->percentage); ?></td>
                                    <td><?php echo e(($earning->status == 0 ? 'Pending':'Completed')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

            <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

            <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

            <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Waseem Computers\Desktop\upwork\php\pakistan\mlm\resources\views/user/accounts/earningAccounts.blade.php ENDPATH**/ ?>