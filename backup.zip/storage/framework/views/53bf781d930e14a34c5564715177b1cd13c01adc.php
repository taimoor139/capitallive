
<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">

                <div class="row">
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">Bonus Account</h5>
                                <p class="card-text">Statistics <i class="bi bi-clipboard-data text-danger"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">$ <?php echo e($directBonuses); ?></h5>
                                <p class="card-text">Direct Bonus <i class="bi bi-person-lines-fill text-primary"></i>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">$ <?php echo e($networkBonuses); ?></h5>
                                <p class="card-text">Network Bonus <i class="bi bi-diagram-2 text-primary"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-sm-6 mb-20">
                        <div class="card border-left-warning">
                            <div class="card-body">
                                <h5 class="card-title p-0 pt-4">$ <?php echo e($pendingBonuses); ?></h5>
                                <p class="card-text">Pending Bonus <i class="bi bi-unlock-fill text-danger"></i></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card border-top-warning  border-bottom-warning">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-diagram-2 text-primary"></i> Bonus History</h5>
                        <table class="table table-hover" id="table">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Date</th>
                                <th scope="col">Type</th>
                                
                                <th scope="col">Amount</th>
                                <th scope="col">Percentage</th>
                                
                                <th scope="col">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $bonuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bonus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(date_format($bonus->created_at, 'd-m-Y')); ?></td>
                                    <td><?php echo e(($bonus->type == 1 ? 'Network' : 'Direct')); ?></td>
                                    <td>$ <?php echo e($bonus->amount); ?></td>
                                    <td><?php echo e($bonus->percentage); ?></td>
                                    <td>
                                        <?php if(7 - ((int) now()->format('d') - (int) date_format($bonus->created_at, 'd')) > 0): ?>
                                            Available after <?php echo e(7 - ((int) now()->format('d') - (int) date_format($bonus->created_at, 'd'))); ?> days
                                        <?php else: ?>
                                            Completed
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                    </div>
                </div>

                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/user/accounts/bonousAccounts.blade.php ENDPATH**/ ?>