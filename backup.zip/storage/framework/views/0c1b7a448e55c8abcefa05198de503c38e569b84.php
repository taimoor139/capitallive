

<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row align-items-center mb-30 justify-content-between">
                <div class="col-lg-6 col-sm-6">
                    <h6 class="page-title">Dashboard</h6>
                </div>
                
                
                
            </div>

            <?php if(Auth::user()->role_id == 1 || (Auth::user()->role_id == 3 && in_array(1, $roles))): ?>
                <div class="row mb-none-30">
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--primary b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-users"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount"><?php echo e($users); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Total Users</span>
                                </div>
                                <a href="<?php echo e(route('all-users')); ?>"
                                   class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View All</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--1 b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-credit-card-alt"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="currency-sign">$</span>
                                    <span class="amount"><?php echo e($usersBalance); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Users Balance</span>
                                </div>
                                <a href="<?php echo e(route('all-users')); ?>"
                                   class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View All</a>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--success b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-users"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount"><?php echo e($verifiedUsers); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Total Verified Users</span>
                                </div>
                                <a href="<?php echo e(route('all-users')); ?>"
                                   class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View All</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--red b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-ban"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount"><?php echo e($bannedUsers); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Banned Users</span>
                                </div>
                                <a href="<?php echo e(route('banned-users')); ?>"
                                   class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View All</a>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    <?php if(Auth::user()->role_id == 1 || (Auth::user()->role_id == 3 && in_array(2, $roles))): ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--cyan b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-money"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="currency-sign">$</span>
                                    <span class="amount"><?php echo e($totalInvestment); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Total Invest</span>
                                </div>
                                
                                   
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--info b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-money"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="currency-sign">$</span>
                                    <span class="amount"><?php echo e($last7DaysInvestment); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Last 7 Days Invest</span>
                                </div>
                                
                                    
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--3 b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-hand-holding-usd"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="currency-sign">$</span>
                                    <span class="amount"><?php echo e($totalReferralBonus); ?></span>
                                </div>
                                <div class="desciption">
                                    <span class="text--small">Total Referral Commission</span>
                                </div>
                                
                                   
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-lg-4 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--17 b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-tree"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="currency-sign">$</span>
                                    <span class="amount">0</span>

                                </div>
                                <div class="desciption">
                                    <span class="text--small">Total Binary Commission</span>
                                </div>
                                
                                   
                            </div>
                        </div>
                    </div>

                    
                        
                            
                                
                            
                            
                                
                                    
                                
                                
                                    
                                
                                
                                   
                            
                        
                    

                    
                        
                            
                                
                            
                            
                                
                                    
                                
                                
                                    
                                
                                
                                   
                            
                        
                    


                    
                        
                            
                                
                            
                            
                                
                                    
                                
                                
                                    
                                
                                
                                   
                            
                        
                    

                    
                        
                            
                                
                            
                            
                                
                                    
                                
                                
                                    
                                
                                
                                   
                            
                        
                    
                </div>
            <?php endif; ?>

            <?php if(Auth::user()->role_id == 1 || (Auth::user()->role_id == 3 && in_array(2, $roles))): ?>
                <div class="row mt-50 mb-none-30">
                    <div class="col-xl-6 mb-30">
                        <div class="card">
                            <div class="card-body" style="position: relative;">
                                <div class="container-fluid p-5">
                                    <div id="barchart_material" style="width: auto; height: 500px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 mb-30">
                        <div class="row mb-none-30">
                            <div class="col-lg-6 col-sm-6 mb-30">
                                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                                    <div class="widget-three__icon b-radius--rounded bg--success  box--shadow2">
                                        <i class="fa fa-money-bill "></i>
                                    </div>
                                    <div class="widget-three__content">
                                        <h2 class="numbers"><?php echo e($totalInvestment); ?> USD</h2>
                                        <p class="text--small">Total Deposit</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6 mb-30">
                                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                                    <div class="widget-three__icon b-radius--rounded bg--teal box--shadow2">
                                        <i class="fa fa-money-check"></i>
                                    </div>
                                    <div class="widget-three__content">
                                        <h2 class="numbers">0 USD</h2>
                                        <p class="text--small">Total Deposit Charge</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-sm-6 mb-30">
                                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                                    <div class="widget-three__icon b-radius--rounded bg--warning  box--shadow2">
                                        <i class="fa fa-spinner"></i>
                                    </div>
                                    <div class="widget-three__content">
                                        <h2 class="numbers"><?php echo e($totalPendingDeposit); ?></h2>
                                        <p class="text--small">Pending Deposit</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6 mb-30">
                                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                                    <div class="widget-three__icon b-radius--rounded bg--danger box--shadow2">
                                        <i class="fa fa-ban "></i>
                                    </div>
                                    <div class="widget-three__content">
                                        <h2 class="numbers"><?php echo e($totalRejectDeposit); ?></h2>
                                        <p class="text--small">Reject Deposit</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- row end -->
            <?php endif; ?>

            <?php if(Auth::user()->role_id == 1 || (Auth::user()->role_id == 3 && in_array(3, $roles))): ?>
                <div class="row mt-50 mb-none-30">


                    <div class="col-xl-4 col-lg-6 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--success b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-money-bill-wave"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount"><?php echo e($totalWithdraw); ?></span>
                                    <span class="currency-sign">USD</span>
                                </div>
                                <div class="desciption">
                                    <span>Total Withdraw</span>
                                </div>
                                <a href="<?php echo e(route('all-withdrawals')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View
                                    All</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--danger b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-money-bill"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount">0.0 </span>
                                    <span class="currency-sign">USD</span>
                                </div>
                                <div class="desciption">
                                    <span>Total Withdraw Charge</span>
                                </div>
                                <a href="<?php echo e(route('all-withdrawals')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View
                                    All</a>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-4 col-lg-6 col-sm-6 mb-30">
                        <div class="dashboard-w1 bg--warning b-radius--10 box-shadow">
                            <div class="icon">
                                <i class="fa fa-spinner"></i>
                            </div>
                            <div class="details">
                                <div class="numbers">
                                    <span class="amount"><?php echo e($totalPendingWithdraw); ?></span>
                                </div>
                                <div class="desciption">
                                    <span>Withdraw Pending</span>
                                </div>

                                <a href="<?php echo e(route('pending-withdrawals')); ?>" class="btn btn-sm text--small bg--white text--black box--shadow3 mt-3">View
                                    All</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(Auth::user()->role_id == 1 || (Auth::user()->role_id == 3 && in_array(1, $roles))): ?>
                <div class="row mb-none-30 mt-5">

                    <div class="col-xl-12 mb-30">
                        <div class="card ">
                            <div class="card-header">
                                <h6 class="card-title mb-0">New User list</h6>
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive--sm table-responsive">
                                    <table class="table table--light style--two">
                                        <thead>
                                        <tr>
                                            <th scope="col">User</th>
                                            <th scope="col">Username</th>
                                            <th scope="col">Email</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $newUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td data-label="User">
                                                    <div class="user">
                                                        <div class="thumb"><img
                                                                    src="https://script.viserlab.com/bisurv/assets/images/avatar.png"
                                                                    alt="image"></div>
                                                        <span class="name"><?php echo e($newUser->name); ?></span>
                                                    </div>
                                                </td>
                                                <td data-label="Username"><a
                                                            href="<?php echo e(route('view-user', $newUser->id)); ?>"><?php echo e($newUser->username); ?></a>
                                                </td>
                                                <td data-label="Email"><?php echo e($newUser->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table><!-- table end -->
                                </div>
                            </div>
                        </div><!-- card end -->
                    </div>

                    <div class="col-xl-6 mb-30">
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    

                    
                    
            
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                
                   
                    
                    
                    
                
                    
                    
                    
                    
                    
                    
            
                    
                    
                    
                    
                    
                    
                    
                      
                    "
                    
                    
                    
                    
                    
                    
                    


                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    


                </div><!-- bodywrapper__inner end -->
            <?php endif; ?>
        </div>

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

        <script type="text/javascript">
            google.charts.load('current', {'packages': ['bar']});
            google.charts.setOnLoadCallback(drawChart);

            function drawChart() {
                var data = google.visualization.arrayToDataTable([
                    ['Month', 'Deposit', 'Withdraw'],
                        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amountData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    ['<?php echo e($amountData[0]); ?>', <?php echo e($amountData[1]); ?>, <?php echo e($amountData[2]); ?>],
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]);

                var options = {
                    chart: {
                        title: 'Monthly Deposit & Withdraw Report',
                    },
                    bars: 'vertical' // Required for Material Bar Charts.
                };

                var chart = new google.charts.Bar(document.getElementById('barchart_material'));

                chart.draw(data, google.charts.Bar.convertOptions(options));
            }
        </script>
        <script>
            <?php if(Session::has('success')): ?>
                toastr.options =
                {
                    "closeButton": true,
                    "progressBar": true
                }
            toastr.success("<?php echo e(session('success')); ?>");
            <?php endif; ?>

                    <?php if(Session::has('error')): ?>
                toastr.options =
                {
                    "closeButton": true,
                    "progressBar": true
                }
            toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>

                    <?php if(Session::has('info')): ?>
                toastr.options =
                {
                    "closeButton": true,
                    "progressBar": true
                }
            toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>

                    <?php if(Session::has('warning')): ?>
                toastr.options =
                {
                    "closeButton": true,
                    "progressBar": true
                }
            toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>
        </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/home.blade.php ENDPATH**/ ?>