
<?php $__env->startSection('content'); ?>
    <div class="body-wrapper">
        <div class="bodywrapper__inner">

            <div class="row align-items-center mb-30 justify-content-between">
                <div class="col-lg-6 col-sm-6">
                    <h6 class="page-title">Support Tickets</h6>
                </div>
                <div class="col-lg-6 col-sm-6 text-sm-right mt-sm-0 mt-3 right-part">
                    <a href="<?php echo e(route('all-tickets')); ?>"
                       class="btn btn-sm btn--dark box--shadow1 text--small"><i class="fa fa-fw fa-backward"></i> Go
                        Back </a>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body ">
                            <h6 class="card-title  mb-4">
                                <div class="row">
                                    <div class="col-sm-8 col-md-6">
                                        <?php if($ticket->status == 0): ?>
                                            <span class="badge badge--success py-1 px-2">Open</span>
                                        <?php else: ?>
                                            <span class="badge badge--danger py-1 px-2">Closed</span>
                                        <?php endif; ?>
                                        [Ticket#<?php echo e($ticket->ticket_id); ?>] <?php echo e($ticket->subject); ?>

                                    </div>
                                    <div class="col-sm-4  col-md-6 text-sm-right mt-sm-0 mt-3">

                                        <button class="btn btn--danger btn-sm" type="button" data-toggle="modal"
                                                data-target="#DelModal">
                                            <i class="fa fa-lg fa-times-circle"></i> Close Ticket
                                        </button>
                                    </div>
                                </div>
                            </h6>

                            <form action="<?php echo e(route('reply-message', $ticket->ticket_id)); ?>"
                                  enctype="multipart/form-data" method="post" class="form-horizontal">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <textarea class="form-control" name="message" rows="3" id="inputMessage"
                                              placeholder="Your Message" spellcheck="false"></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="inputAttachments">Attachments</label>
                                    <div class="file-upload-wrapper" data-text="Select your file!">
                                        <input type="file" name="attachments" id="inputAttachments"
                                               class="file-upload-field">
                                    </div>
                                    <div id="fileUploadsContainer"></div>
                                </div>
                                <div class=" ticket-attachments-message text-muted mt-3">
                                    Allowed File Extensions: .jpg, .jpeg, .png, .pdf, .doc, .docx
                                </div>

                                
                                


                                <button class="btn btn--primary btn-block mt-4" type="submit" name="replayTicket"
                                        value="1"><i class="fa fa-fw fa-lg fa-reply"></i> Reply
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-lg-12">
                    <?php $__currentLoopData = $ticket->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-body">
                            <div class="row border border-primary border-radius-3 my-3 mx-2 <?php echo e(($ticket->user_id == $message->user_id ? 'bg--info' : 'bg--success')); ?>">
                                <div class="col-md-3 border-right text-right">
                                    <h5 class="my-3"><?php echo e($message->users->name); ?></h5>
                                    <p><a href="<?php echo e(route('view-user', $ticket->user_id)); ?>">@ <?php echo e($message->users->username); ?></a>
                                    </p>
                                    <button data-id="<?php echo e($message->id); ?>" type="button" data-toggle="modal" data-target="#DelMessage"
                                            class="btn btn-danger btn-sm my-3 delete-message"><i
                                                class="fa fa-trash"></i> Delete
                                    </button>
                                </div>

                                <div class="col-md-9">
                                    <p class="text-muted font-weight-bold my-3">
                                        Posted on <?php echo e(date_format($message->created_at, 'M d, Y')); ?> @ <?php echo e(date_format($message->created_at, 'H:i A')); ?></p>
                                    <p><?php echo e($message->message); ?></p>
                                    <?php if($message->file): ?>
                                        <a href="<?php echo e(route('admin-download-message', $message->file)); ?>"
                                           target="_blank" class="text-danger fw-bolder">
                                            <img
                                                    src="<?php echo e(public_path()."/uploads/ticket_attachments/".$message->file); ?>"
                                                    class="img-thumbnail ml-3" width="100">
                                            Attached File
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="modal fade" id="DelModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"> Close Support Ticket!</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <strong>Are you want to Close This Support Ticket?</strong>
                        </div>
                        <div class="modal-footer">
                            <form method="post" action="<?php echo e(route('closed-ticket', $ticket->ticket_id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="button" class="btn btn--secondary" data-dismiss="modal">No</button>
                                <button type="submit" class="btn btn--success" name="replayTicket" value="2"> Close
                                    Ticket
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="modal fade" id="DelMessage" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                 aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Delete Reply!</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <strong>Are you sure to delete this?</strong>
                        </div>
                        <div class="modal-footer">
                            <form method="post" action="<?php echo e(route('delete-message')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="message_id" class="message_id">
                                <button type="button" class="btn btn--dark" data-dismiss="modal">No</button>
                                <button type="submit" class="btn btn--danger"><i class="fa fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>

                    </div>
                </div>
            </div>


        </div><!-- bodywrapper__inner end -->
    </div>

    <script>
        'use strict';
        (function ($) {
            $('.delete-message').on('click', function (e) {
                $('.message_id').val($(this).data('id'));
            });

//            $('.add-more').on('click', function () {
//                $("#fileUploadsContainer").append(`
//                                            <div class="file-upload-wrapper" data-text="Select your file!">
//                                            <input type="file" name="attachments[]" id="inputAttachments" class="file-upload-field"/>
//                                            </div>`)
//            })
        })(jQuery)
    </script>

    <script>
        <?php if(Session::has('success')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

                <?php if(Session::has('error')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

                <?php if(Session::has('info')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

                <?php if(Session::has('warning')): ?>
            toastr.options =
            {
                "closeButton": true,
                "progressBar": true
            }
        toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u511512799/domains/capitalfirst.live/public_html/resources/views/admin/support/view.blade.php ENDPATH**/ ?>