<?php $__env->startSection('content'); ?>
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <div class="card border-top-warning border-bottom-warning">
                    <div class="card-body">
                        <h5 class="card-title"><i class="bi bi-journal-plus"></i> Forex Education</h5>
                        <div class="alert-danger p-3">
                            <strong>No Education Available!</strong> No Educational articles available currently for your
                            region.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\upwork\php\pakistan\mlm\resources\views/user/education/education.blade.php ENDPATH**/ ?>